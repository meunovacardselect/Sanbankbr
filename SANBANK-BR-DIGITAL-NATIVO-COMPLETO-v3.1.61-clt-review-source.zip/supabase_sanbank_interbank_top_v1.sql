-- SANBANK ↔ MEU NOVA BANK: Transferência TOP sem revisão administrativa.
-- Movimento demonstrativo apenas entre ledgers internos; não é Pix/DICT nem liquidação externa.
begin;

create table if not exists public.sanbank_top_transfers (
  transfer_id uuid primary key,
  direction text not null check(direction in ('outgoing','incoming')),
  source_institution text not null check(source_institution in ('SANBANK BR DIGITAL','MEU NOVA BANK BR DIGITAL')),
  destination_institution text not null check(destination_institution in ('SANBANK BR DIGITAL','MEU NOVA BANK BR DIGITAL')),
  sender_account text not null check(sender_account ~ '^[0-9]{6,7}$'),
  sender_name text not null check(char_length(sender_name) between 1 and 120),
  recipient_account text not null check(recipient_account ~ '^[0-9]{6,7}$'),
  recipient_name text not null check(char_length(recipient_name) between 1 and 120),
  amount numeric(16,2) not null check(amount>0),
  status text not null default 'prepared' check(status in ('prepared','source_debited','completed','aborted','insufficient_funds')),
  created_at timestamptz not null default timezone('utc',now()),
  updated_at timestamptz not null default timezone('utc',now()),
  source_debited_at timestamptz,
  destination_credited_at timestamptz,
  check(source_institution<>destination_institution)
);
create index if not exists sanbank_top_sender_created_idx on public.sanbank_top_transfers(sender_account,created_at desc) where direction='outgoing';
create index if not exists sanbank_top_recipient_created_idx on public.sanbank_top_transfers(recipient_account,created_at desc) where direction='incoming';
alter table public.sanbank_top_transfers enable row level security;
alter table public.sanbank_top_transfers force row level security;
revoke all on public.sanbank_top_transfers from public,anon,authenticated;
grant all on public.sanbank_top_transfers to service_role;

create or replace function public.sanbank_top_create_outgoing(
  p_transfer_id uuid,p_sender_account text,p_recipient_account text,p_recipient_name text,p_amount numeric
) returns jsonb language plpgsql security definer set search_path=public,extensions as $$
declare v_sender public.sanbank_accounts%rowtype; v_existing public.sanbank_top_transfers%rowtype; v_amount numeric(16,2); v_name text;
begin
  if p_transfer_id is null or p_sender_account is null or p_sender_account !~ '^[0-9]{6,7}$' then raise exception 'TOP_SENDER_INVALID'; end if;
  if p_recipient_account is null or p_recipient_account !~ '^[0-9]{6,7}$' then raise exception 'TOP_RECIPIENT_INVALID'; end if;
  if p_amount is null or p_amount<=0 or p_amount>99999999999999.99 or p_amount<>round(p_amount,2) then raise exception 'TOP_AMOUNT_INVALID'; end if;
  if char_length(btrim(coalesce(p_recipient_name,''))) not between 1 and 120 then raise exception 'TOP_RECIPIENT_NAME_INVALID'; end if;
  v_amount:=p_amount::numeric(16,2);
  select * into v_sender from public.sanbank_accounts where account=p_sender_account for update;
  if v_sender.account is null then raise exception 'TOP_SENDER_NOT_FOUND'; end if;
  if lower(coalesce(v_sender.account_status,'')) in ('closed','encerrada','locked','bloqueada','blocked') or coalesce(v_sender.access_enabled,true) is false or coalesce(v_sender.client_access_enabled,true) is false then raise exception 'TOP_SENDER_INACTIVE'; end if;
  v_name:=left(coalesce(nullif(btrim(v_sender.name),''),'Titular SANBANK'),120);
  insert into public.sanbank_top_transfers(transfer_id,direction,source_institution,destination_institution,sender_account,sender_name,recipient_account,recipient_name,amount,status)
  values(p_transfer_id,'outgoing','SANBANK BR DIGITAL','MEU NOVA BANK BR DIGITAL',p_sender_account,v_name,p_recipient_account,btrim(p_recipient_name),v_amount,'prepared') on conflict(transfer_id) do nothing;
  select * into v_existing from public.sanbank_top_transfers where transfer_id=p_transfer_id for update;
  if v_existing.direction<>'outgoing' or v_existing.sender_account<>p_sender_account or v_existing.recipient_account<>p_recipient_account or v_existing.amount<>v_amount then raise exception 'TOP_IDEMPOTENCY_CONFLICT'; end if;
  return jsonb_build_object('ok',true,'transfer_id',p_transfer_id,'status',v_existing.status,'sender_account',v_existing.sender_account,'sender_name',v_existing.sender_name,'recipient_account',v_existing.recipient_account,'amount',v_existing.amount);
end;$$;
revoke all on function public.sanbank_top_create_outgoing(uuid,text,text,text,numeric) from public,anon,authenticated;
grant execute on function public.sanbank_top_create_outgoing(uuid,text,text,text,numeric) to service_role;

create or replace function public.sanbank_top_prepare_incoming(
  p_transfer_id uuid,p_source_institution text,p_sender_account text,p_sender_name text,p_recipient_account text,p_amount numeric
) returns jsonb language plpgsql security definer set search_path=public,extensions as $$
declare v_recipient public.sanbank_accounts%rowtype; v_existing public.sanbank_top_transfers%rowtype; v_amount numeric(16,2); v_name text;
begin
  if p_source_institution<>'MEU NOVA BANK BR DIGITAL' then raise exception 'TOP_SAME_OR_UNSUPPORTED_INSTITUTION'; end if;
  if p_transfer_id is null or p_sender_account !~ '^[0-9]{6,7}$' or p_recipient_account !~ '^[0-9]{6,7}$' then raise exception 'TOP_TRANSFER_DATA_INVALID'; end if;
  if char_length(btrim(coalesce(p_sender_name,''))) not between 1 and 120 then raise exception 'TOP_SENDER_NAME_INVALID'; end if;
  if p_amount is null or p_amount<=0 or p_amount>99999999999999.99 or p_amount<>round(p_amount,2) then raise exception 'TOP_AMOUNT_INVALID'; end if;
  v_amount:=p_amount::numeric(16,2);
  select * into v_recipient from public.sanbank_accounts where account=p_recipient_account for update;
  if v_recipient.account is null then raise exception 'TOP_RECIPIENT_NOT_FOUND'; end if;
  if lower(coalesce(v_recipient.account_status,'')) in ('closed','encerrada','locked','bloqueada','blocked') or coalesce(v_recipient.access_enabled,true) is false or coalesce(v_recipient.client_access_enabled,true) is false then raise exception 'TOP_RECIPIENT_INACTIVE'; end if;
  v_name:=left(coalesce(nullif(btrim(v_recipient.name),''),'Titular SANBANK'),120);
  insert into public.sanbank_top_transfers(transfer_id,direction,source_institution,destination_institution,sender_account,sender_name,recipient_account,recipient_name,amount,status)
  values(p_transfer_id,'incoming','MEU NOVA BANK BR DIGITAL','SANBANK BR DIGITAL',p_sender_account,btrim(p_sender_name),p_recipient_account,v_name,v_amount,'prepared') on conflict(transfer_id) do nothing;
  select * into v_existing from public.sanbank_top_transfers where transfer_id=p_transfer_id for update;
  if v_existing.direction<>'incoming' or v_existing.sender_account<>p_sender_account or v_existing.recipient_account<>p_recipient_account or v_existing.amount<>v_amount then raise exception 'TOP_IDEMPOTENCY_CONFLICT'; end if;
  return jsonb_build_object('ok',true,'transfer_id',p_transfer_id,'status',v_existing.status,'recipient_account',v_existing.recipient_account,'recipient_name',v_existing.recipient_name,'amount',v_existing.amount);
end;$$;
revoke all on function public.sanbank_top_prepare_incoming(uuid,text,text,text,text,numeric) from public,anon,authenticated;
grant execute on function public.sanbank_top_prepare_incoming(uuid,text,text,text,text,numeric) to service_role;

create or replace function public.sanbank_top_debit_outgoing(p_transfer_id uuid)
returns jsonb language plpgsql security definer set search_path=public,extensions as $$
declare v_row public.sanbank_top_transfers%rowtype; v_account public.sanbank_accounts%rowtype; v_balance numeric:=0; v_limit numeric:=0; v_available numeric:=0; v_new_balance numeric:=0; v_blocked boolean:=false; v_leg text; v_next integer;
begin
  select * into v_row from public.sanbank_top_transfers where transfer_id=p_transfer_id and direction='outgoing' for update;
  if v_row.transfer_id is null then raise exception 'TOP_TRANSFER_NOT_FOUND'; end if;
  if v_row.status in ('source_debited','completed') then return jsonb_build_object('ok',true,'status',v_row.status,'transfer_id',p_transfer_id,'debit_confirmed',true); end if;
  if v_row.status<>'prepared' then raise exception 'TOP_TRANSFER_STATE_INVALID'; end if;
  select * into v_account from public.sanbank_accounts where account=v_row.sender_account for update;
  if v_account.account is null then raise exception 'TOP_SENDER_NOT_FOUND'; end if;
  if lower(coalesce(v_account.account_status,'')) in ('closed','encerrada','locked','bloqueada','blocked') or coalesce(v_account.access_enabled,true) is false or coalesce(v_account.client_access_enabled,true) is false then raise exception 'TOP_SENDER_INACTIVE'; end if;
  v_blocked:=coalesce(public.sanbank_bool(v_account.legacy_data->>'security_locked'),false)
    or coalesce(public.sanbank_bool(v_account.legacy_data->>'account_locked'),false)
    or coalesce(public.sanbank_bool(v_account.legacy_data->>'user_blocked'),false)
    or coalesce(public.sanbank_bool(v_account.legacy_data->>'security_balance_blocked'),false)
    or coalesce(public.sanbank_bool(v_account.legacy_data->>'available_balance_blocked'),false)
    or coalesce(public.sanbank_bool(v_account.legacy_data->>'balance_security_blocked'),false)
    or lower(trim(coalesce(v_account.legacy_data->>'security_status',''))) in ('bloqueado','bloqueada','blocked','locked','security_locked','security_blocked');
  if v_blocked then raise exception 'TOP_SECURITY_BLOCKED'; end if;
  v_balance:=coalesce(v_account.balance,0); v_limit:=greatest(coalesce(v_account.overdraft_limit,0),0);
  if coalesce(v_account.overdraft_enabled,false) then v_available:=greatest(v_balance,0)+case when v_balance<0 then greatest(0,v_limit+v_balance) else v_limit end; else v_available:=greatest(v_balance,0); end if;
  if v_row.amount>v_available+0.005 then update public.sanbank_top_transfers set status='insufficient_funds',updated_at=timezone('utc',now()) where transfer_id=p_transfer_id; return jsonb_build_object('ok',false,'status','insufficient_funds','available',v_available,'transfer_id',p_transfer_id); end if;
  v_new_balance:=round(v_balance-v_row.amount,2);
  update public.sanbank_accounts set balance=v_new_balance,legacy_data=coalesce(legacy_data,'{}'::jsonb)||jsonb_build_object('last_interbank_top_transfer_id',p_transfer_id,'last_interbank_top_transfer_at',timezone('utc',now())),updated_at=timezone('utc',now()) where account=v_row.sender_account;
  v_leg:='TOP-DEBIT-'||p_transfer_id::text;
  if not exists(select 1 from public.sanbank_legacy_records where source_tab='extrato' and (legacy_id=v_leg or payload->>'id'=v_leg)) then
    perform pg_advisory_xact_lock(hashtextextended('sanbank-extrato-source-row',0));
    select coalesce(max(source_row),0)+1 into v_next from public.sanbank_legacy_records where source_tab='extrato';
    insert into public.sanbank_legacy_records(source_tab,source_row,legacy_id,account,payload) values('extrato',v_next,v_leg,v_row.sender_account,jsonb_build_object('id',v_leg,'transaction_id',p_transfer_id,'leg_id',v_leg,'account',v_row.sender_account,'sender_account',v_row.sender_account,'target_account',v_row.recipient_account,'target_institution','MEU NOVA BANK BR DIGITAL','amount',to_char(-v_row.amount,'FM999999999990.00'),'title','Transferência TOP para MEU NOVA BANK','description','Débito demonstrativo de transferência entre ledgers. ID '||p_transfer_id::text,'transaction_type','INTERBANK_TOP_DEBIT','type','out','date',timezone('utc',now()),'status','completed','settlement_status','pending_destination_credit','new_balance',v_new_balance,'debit_source',case when v_balance>=v_row.amount then 'saldo_disponivel' else 'cheque_especial' end));
  end if;
  update public.sanbank_top_transfers set status='source_debited',source_debited_at=timezone('utc',now()),updated_at=timezone('utc',now()) where transfer_id=p_transfer_id;
  return jsonb_build_object('ok',true,'status','source_debited','transfer_id',p_transfer_id,'debit_confirmed',true,'sender_new_balance',v_new_balance);
end;$$;
revoke all on function public.sanbank_top_debit_outgoing(uuid) from public,anon,authenticated;
grant execute on function public.sanbank_top_debit_outgoing(uuid) to service_role;

create or replace function public.sanbank_top_credit_incoming(p_transfer_id uuid)
returns jsonb language plpgsql security definer set search_path=public,extensions as $$
declare v_row public.sanbank_top_transfers%rowtype; v_account public.sanbank_accounts%rowtype; v_new_balance numeric; v_leg text; v_next integer;
begin
  select * into v_row from public.sanbank_top_transfers where transfer_id=p_transfer_id and direction='incoming' for update;
  if v_row.transfer_id is null then raise exception 'TOP_TRANSFER_NOT_FOUND'; end if;
  if v_row.status='completed' then return jsonb_build_object('ok',true,'status','completed','transfer_id',p_transfer_id,'credit_confirmed',true); end if;
  if v_row.status<>'prepared' then raise exception 'TOP_TRANSFER_STATE_INVALID'; end if;
  select * into v_account from public.sanbank_accounts where account=v_row.recipient_account for update;
  if v_account.account is null then raise exception 'TOP_RECIPIENT_NOT_FOUND'; end if;
  v_new_balance:=round(coalesce(v_account.balance,0)+v_row.amount,2);
  update public.sanbank_accounts set balance=v_new_balance,legacy_data=coalesce(legacy_data,'{}'::jsonb)||jsonb_build_object('last_interbank_top_credit_id',p_transfer_id,'last_interbank_top_credit_at',timezone('utc',now())),updated_at=timezone('utc',now()) where account=v_row.recipient_account;
  v_leg:='TOP-CREDIT-'||p_transfer_id::text;
  if not exists(select 1 from public.sanbank_legacy_records where source_tab='extrato' and (legacy_id=v_leg or payload->>'id'=v_leg)) then
    perform pg_advisory_xact_lock(hashtextextended('sanbank-extrato-source-row',0));
    select coalesce(max(source_row),0)+1 into v_next from public.sanbank_legacy_records where source_tab='extrato';
    insert into public.sanbank_legacy_records(source_tab,source_row,legacy_id,account,payload) values('extrato',v_next,v_leg,v_row.recipient_account,jsonb_build_object('id',v_leg,'transaction_id',p_transfer_id,'leg_id',v_leg,'account',v_row.recipient_account,'sender_account',v_row.sender_account,'target_account',v_row.recipient_account,'target_institution','SANBANK BR DIGITAL','amount',to_char(v_row.amount,'FM999999999990.00'),'title','Transferência TOP recebida','description','Crédito demonstrativo recebido de MEU NOVA BANK BR DIGITAL · conta '||v_row.sender_account,'transaction_type','INTERBANK_TOP_CREDIT','type','in','date',timezone('utc',now()),'status','completed','settlement_status','internal_ledger_only','new_balance',v_new_balance));
  end if;
  update public.sanbank_top_transfers set status='completed',destination_credited_at=timezone('utc',now()),updated_at=timezone('utc',now()) where transfer_id=p_transfer_id;
  return jsonb_build_object('ok',true,'status','completed','transfer_id',p_transfer_id,'credit_confirmed',true);
end;$$;
revoke all on function public.sanbank_top_credit_incoming(uuid) from public,anon,authenticated;
grant execute on function public.sanbank_top_credit_incoming(uuid) to service_role;

create or replace function public.sanbank_top_finish_outgoing(p_transfer_id uuid,p_status text)
returns jsonb language plpgsql security definer set search_path=public,extensions as $$
declare v_row public.sanbank_top_transfers%rowtype; v_next text:=lower(coalesce(p_status,''));
begin
  select * into v_row from public.sanbank_top_transfers where transfer_id=p_transfer_id and direction='outgoing' for update;
  if v_row.transfer_id is null then raise exception 'TOP_TRANSFER_NOT_FOUND'; end if;
  if v_row.status='completed' then return jsonb_build_object('ok',true,'status','completed','transfer_id',p_transfer_id); end if;
  if v_next='completed' and v_row.status='source_debited' then update public.sanbank_top_transfers set status='completed',destination_credited_at=timezone('utc',now()),updated_at=timezone('utc',now()) where transfer_id=p_transfer_id;
  elsif v_next='aborted' and v_row.status in ('prepared','insufficient_funds') then update public.sanbank_top_transfers set status='aborted',updated_at=timezone('utc',now()) where transfer_id=p_transfer_id;
  else raise exception 'TOP_TRANSFER_STATE_CONFLICT'; end if;
  return jsonb_build_object('ok',true,'status',v_next,'transfer_id',p_transfer_id);
end;$$;
revoke all on function public.sanbank_top_finish_outgoing(uuid,text) from public,anon,authenticated;
grant execute on function public.sanbank_top_finish_outgoing(uuid,text) to service_role;

create schema if not exists private;
revoke all on schema private from public,anon,authenticated;
grant usage on schema private to service_role;
create table if not exists private.sanbank_top_lookup_limits(
 actor_account text not null,
 window_started_at timestamptz not null,
 attempts integer not null default 1 check(attempts between 1 and 20),
 primary key(actor_account,window_started_at)
);
revoke all on private.sanbank_top_lookup_limits from public,anon,authenticated;
grant all on private.sanbank_top_lookup_limits to service_role;
create or replace function public.sanbank_top_lookup_allowed(p_actor_account text)
returns boolean language plpgsql security definer set search_path='' as $$
declare v_window timestamptz:=date_trunc('minute',clock_timestamp()); v_attempts integer;
begin
 if p_actor_account is null or p_actor_account !~ '^[0-9]{6,7}$' then return false; end if;
 insert into private.sanbank_top_lookup_limits(actor_account,window_started_at,attempts) values(p_actor_account,v_window,1)
 on conflict(actor_account,window_started_at) do update set attempts=private.sanbank_top_lookup_limits.attempts+1 returning attempts into v_attempts;
 delete from private.sanbank_top_lookup_limits where window_started_at<v_window-interval '10 minutes';
 return v_attempts<=20;
end;$$;
revoke all on function public.sanbank_top_lookup_allowed(text) from public,anon,authenticated;
grant execute on function public.sanbank_top_lookup_allowed(text) to service_role;

create or replace function public.sanbank_top_abort_incoming(p_transfer_id uuid)
returns jsonb language plpgsql security definer set search_path=public,extensions as $$
declare v_row public.sanbank_top_transfers%rowtype;
begin
 select * into v_row from public.sanbank_top_transfers where transfer_id=p_transfer_id and direction='incoming' for update;
 if v_row.transfer_id is null then raise exception 'TOP_TRANSFER_NOT_FOUND'; end if;
 if v_row.status='aborted' then return jsonb_build_object('ok',true,'status','aborted','transfer_id',p_transfer_id); end if;
 if v_row.status<>'prepared' then raise exception 'TOP_TRANSFER_ABORT_UNSAFE'; end if;
 update public.sanbank_top_transfers set status='aborted',updated_at=timezone('utc',now()) where transfer_id=p_transfer_id;
 return jsonb_build_object('ok',true,'status','aborted','transfer_id',p_transfer_id);
end;$$;
revoke all on function public.sanbank_top_abort_incoming(uuid) from public,anon,authenticated;
grant execute on function public.sanbank_top_abort_incoming(uuid) to service_role;

commit;
