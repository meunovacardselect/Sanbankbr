-- SANBANK BR DIGITAL — lançamentos futuros de crédito
-- Execute este arquivo no SQL Editor do projeto Supabase SANBANK.
-- O saldo nunca é alterado no cadastro. A liquidação é atômica e idempotente.

create table if not exists public.sanbank_scheduled_credits (
  id text primary key,
  account text not null references public.sanbank_accounts(account),
  amount numeric(18,2) not null check (amount > 0),
  release_date date not null,
  description text not null,
  institution text not null,
  status text not null default 'agendado' check (status in ('agendado', 'creditado')),
  created_by text not null,
  created_at timestamptz not null default timezone('utc', now()),
  settled_at timestamptz,
  statement_id text unique
);
create index if not exists sanbank_scheduled_credits_account_date_idx
  on public.sanbank_scheduled_credits(account, release_date, status);
create index if not exists sanbank_scheduled_credits_due_idx
  on public.sanbank_scheduled_credits(release_date, status);
alter table public.sanbank_scheduled_credits enable row level security;
revoke all on table public.sanbank_scheduled_credits from public, anon, authenticated;

-- Somente o Gerente SANBANK com sessão administrativa pode programar créditos.
create or replace function public.sanbank_admin_create_scheduled_credit(
  p_account text,
  p_amount numeric,
  p_release_date date,
  p_description text,
  p_institution text
)
returns jsonb
language plpgsql security definer set search_path=public,extensions
as $$
declare
  v_id text;
  v_admin text := public.sanbank_current_account();
  v_description text := nullif(trim(coalesce(p_description, '')), '');
  v_institution text := nullif(trim(coalesce(p_institution, '')), '');
begin
  if not public.sanbank_is_admin() then raise exception 'SANBANK_ADMIN_REQUIRED'; end if;
  if coalesce(p_account, '') !~ '^\d{6}$' then raise exception 'SANBANK_INVALID_ACCOUNT'; end if;
  if p_amount is null or p_amount <= 0 or p_amount > 9999999999999999.99 then raise exception 'SANBANK_INVALID_AMOUNT'; end if;
  if p_release_date is null or p_release_date < (timezone('America/Sao_Paulo', now()))::date then raise exception 'SANBANK_INVALID_RELEASE_DATE'; end if;
  if v_description is null or length(v_description) > 240 then raise exception 'SANBANK_INVALID_DESCRIPTION'; end if;
  if v_institution is null or length(v_institution) > 120 then raise exception 'SANBANK_INVALID_INSTITUTION'; end if;
  if not exists (select 1 from public.sanbank_accounts a where a.account = p_account) then raise exception 'SANBANK_ACCOUNT_NOT_FOUND'; end if;

  v_id := 'SC-' || replace(gen_random_uuid()::text, '-', '');
  insert into public.sanbank_scheduled_credits(id, account, amount, release_date, description, institution, status, created_by)
  values (v_id, p_account, round(p_amount, 2), p_release_date, v_description, v_institution, 'agendado', coalesce(v_admin, 'admin'));
  return jsonb_build_object('id', v_id, 'account', p_account, 'amount', round(p_amount, 2),
    'release_date', p_release_date, 'description', v_description, 'institution', v_institution,
    'status', 'agendado', 'created_by', coalesce(v_admin, 'admin'));
end;
$$;
revoke all on function public.sanbank_admin_create_scheduled_credit(text,numeric,date,text,text) from public;
grant execute on function public.sanbank_admin_create_scheduled_credit(text,numeric,date,text,text) to anon, authenticated;

-- Consulta administrativa por conta; um cliente só consegue consultar a própria conta.
create or replace function public.sanbank_list_scheduled_credits(p_account text default null)
returns setof jsonb
language plpgsql stable security definer set search_path=public,extensions
as $$
declare
  v_me text := public.sanbank_current_account();
  v_admin boolean := public.sanbank_is_admin();
  v_account text;
begin
  if v_me is null then raise exception 'SANBANK_SESSION_REQUIRED'; end if;
  if v_admin then
    v_account := nullif(trim(coalesce(p_account, '')), '');
  else
    v_account := v_me;
  end if;
  return query
    select jsonb_build_object(
      'id', c.id, 'account', c.account, 'amount', c.amount,
      'release_date', c.release_date, 'description', c.description,
      'institution', c.institution, 'status', c.status,
      'created_by', c.created_by, 'created_at', c.created_at,
      'settled_at', c.settled_at, 'statement_id', c.statement_id,
      'title', c.description, 'type', 'in', 'direction', 'in',
      'future', (c.status = 'agendado'), 'is_future', (c.status = 'agendado'),
      'lancamento_futuro', (c.status = 'agendado'), 'future_entry', (c.status = 'agendado')
    )
    from public.sanbank_scheduled_credits c
    where (v_account is null or c.account = v_account)
    order by c.release_date desc, c.created_at desc;
end;
$$;
revoke all on function public.sanbank_list_scheduled_credits(text) from public;
grant execute on function public.sanbank_list_scheduled_credits(text) to anon, authenticated;

-- Função interna privilegiada: processa um lançamento dentro de uma única transação.
create or replace function public.sanbank_process_scheduled_credits(p_account text default null)
returns integer
language plpgsql security definer set search_path=public,extensions
as $$
declare
  v_credit public.sanbank_scheduled_credits%rowtype;
  v_today date := (timezone('America/Sao_Paulo', now()))::date;
  v_balance numeric(18,2);
  v_statement_id text;
  v_next_row integer;
  v_count integer := 0;
begin
  -- Protege a sequência source_row da tabela legada contra liquidações simultâneas.
  perform pg_advisory_xact_lock(hashtext('sanbank_legacy_records:extrato'));
  for v_credit in
    select c.*
    from public.sanbank_scheduled_credits c
    where c.status = 'agendado'
      and c.release_date <= v_today
      and (p_account is null or c.account = p_account)
    order by c.release_date, c.created_at, c.id
    for update skip locked
  loop
    select a.balance into v_balance
      from public.sanbank_accounts a
      where a.account = v_credit.account
      for update;
    if not found then
      continue;
    end if;

    update public.sanbank_accounts
      set balance = balance + v_credit.amount,
          updated_at = timezone('utc', now())
      where account = v_credit.account;

    v_statement_id := 'FUTURE-CREDIT-' || v_credit.id;
    select coalesce(max(r.source_row), 0) + 1 into v_next_row
      from public.sanbank_legacy_records r
      where r.source_tab = 'extrato';

    insert into public.sanbank_legacy_records(source_tab, source_row, legacy_id, account, payload)
    values (
      'extrato', v_next_row, v_statement_id, v_credit.account,
      jsonb_build_object(
        'id', v_statement_id,
        'account', v_credit.account,
        'type', 'in', 'direction', 'in', 'flow', 'in',
        'amount', v_credit.amount,
        'title', v_credit.description,
        'description', 'Crédito recebido da instituição: ' || v_credit.institution || ' — ' || v_credit.description,
        'transaction_type', 'ADMIN_CREDIT',
        'status', 'concluido',
        'date', v_credit.release_date::text,
        'created_at', timezone('utc', now()),
        'institution', v_credit.institution,
        'source_scheduled_credit_id', v_credit.id,
        'admin_by', v_credit.created_by
      )
    );

    update public.sanbank_scheduled_credits
      set status = 'creditado', settled_at = timezone('utc', now()), statement_id = v_statement_id
      where id = v_credit.id and status = 'agendado';
    if found then v_count := v_count + 1; end if;
  end loop;
  return v_count;
end;
$$;
revoke all on function public.sanbank_process_scheduled_credits(text) from public, anon, authenticated;

-- Acionada pelo app do cliente ao abrir/atualizar a consulta; processa somente a conta da sessão.
create or replace function public.sanbank_settle_scheduled_credits()
returns jsonb
language plpgsql security definer set search_path=public,extensions
as $$
declare
  v_account text := public.sanbank_current_account();
  v_settled integer;
begin
  if v_account is null then raise exception 'SANBANK_SESSION_REQUIRED'; end if;
  v_settled := public.sanbank_process_scheduled_credits(v_account);
  return jsonb_build_object('settled', v_settled, 'account', v_account);
end;
$$;
revoke all on function public.sanbank_settle_scheduled_credits() from public;
grant execute on function public.sanbank_settle_scheduled_credits() to anon, authenticated;

-- Processa independentemente da abertura do app se pg_cron estiver habilitado no Supabase.
create or replace function public.sanbank_process_all_due_scheduled_credits()
returns integer
language plpgsql security definer set search_path=public,extensions
as $$
begin
  return public.sanbank_process_scheduled_credits(null);
end;
$$;
revoke all on function public.sanbank_process_all_due_scheduled_credits() from public, anon, authenticated;

do $$
begin
  begin
    execute 'create extension if not exists pg_cron';
  exception when others then
    raise notice 'pg_cron não pôde ser habilitado automaticamente; a liquidação ao consultar a função continuará disponível.';
  end;
  if to_regclass('cron.job') is not null then
    begin
      execute $q$select cron.unschedule(jobid) from cron.job where jobname = 'sanbank-scheduled-credit-release'$q$;
    exception when others then
      null;
    end;
    begin
      execute $q$select cron.schedule('sanbank-scheduled-credit-release', '* * * * *', 'select public.sanbank_process_all_due_scheduled_credits();')$q$;
      raise notice 'Liquidação automática de lançamentos futuros agendada a cada minuto.';
    exception when others then
      raise notice 'Não foi possível criar o agendamento pg_cron; a liquidação ao consultar a função continuará disponível.';
    end;
  else
    raise notice 'pg_cron não está habilitado; habilite a extensão pg_cron para liquidação automática em segundo plano.';
  end if;
end;
$$;
