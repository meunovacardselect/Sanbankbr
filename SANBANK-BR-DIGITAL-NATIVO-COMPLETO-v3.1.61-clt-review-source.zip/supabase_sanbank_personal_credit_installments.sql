-- SANBANK: crédito pessoal aprovado e cobrança mensal idempotente.
-- Aplicar no projeto Supabase SANBANK depois de revisar os parâmetros da política de crédito.
-- O app mostra a parcela como estimativa; as condições gravadas na solicitação são a referência inicial.

create table if not exists public.sanbank_personal_loan_contracts (
  loan_id text primary key,
  account text not null references public.sanbank_accounts(account),
  principal numeric(18,2) not null check (principal between 100 and 120000),
  outstanding_balance numeric(18,2) not null check (outstanding_balance >= 0),
  installment_amount numeric(18,2) not null check (installment_amount > 0),
  installment_count integer not null check (installment_count between 2 and 48),
  installments_paid integer not null default 0,
  due_day integer not null check (due_day between 1 and 28),
  next_due_date date not null,
  monthly_rate numeric(9,6) not null,
  contract_status text not null default 'ativo' check (contract_status in ('ativo','quitado','cancelado')),
  last_collection_status text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.sanbank_personal_loan_events (
  event_id text primary key,
  loan_id text not null references public.sanbank_personal_loan_contracts(loan_id),
  account text not null,
  event_type text not null check (event_type in ('liberacao','parcela')),
  amount numeric(18,2) not null,
  event_date timestamptz not null default now()
);

alter table public.sanbank_personal_loan_contracts enable row level security;
alter table public.sanbank_personal_loan_events enable row level security;
revoke all on public.sanbank_personal_loan_contracts from public, anon, authenticated;
revoke all on public.sanbank_personal_loan_events from public, anon, authenticated;

create or replace function public.sanbank_personal_loan_on_approval()
returns trigger language plpgsql security definer set search_path=public,extensions
as $$
declare
  v_old_status text := case when tg_op = 'UPDATE' then coalesce(old.payload->>'status','') else '' end;
  v_status text := coalesce(new.payload->>'status','');
  v_product text := lower(coalesce(new.payload->>'product', new.payload->>'tipo',''));
  v_account text := coalesce(new.account, new.payload->>'account');
  v_amount numeric(18,2) := coalesce(nullif(new.payload->>'amount','')::numeric, nullif(new.payload->>'valorSolicitado','')::numeric);
  v_months integer := coalesce(nullif(new.payload->>'months','')::integer, nullif(new.payload->>'parcelas','')::integer);
  v_day integer := coalesce(nullif(new.payload->>'requested_due_day','')::integer, nullif(new.payload->>'due_day','')::integer);
  v_rate numeric(9,6) := coalesce(nullif(new.payload->>'monthly_rate_estimated','')::numeric, 0.0184);
  v_installment numeric(18,2);
  v_due date;
  v_loan_id text := coalesce(new.legacy_id, new.payload->>'id');
  v_event_id text;
  v_source_row integer;
begin
  if new.source_tab <> 'emprestimos' or v_status <> 'aprovado' or v_old_status = 'aprovado' then return new; end if;
  if not public.sanbank_is_admin() then raise exception 'SANBANK_ADMIN_REQUIRED_FOR_LOAN_APPROVAL'; end if;
  if v_product not in ('credito_pessoal','personal_loan') then return new; end if;
  if v_account is null or v_loan_id is null or v_amount < 100 or v_amount > 120000 or v_months < 2 or v_months > 48 or v_day < 1 or v_day > 28 or v_rate <= 0 or v_rate > 0.30 then
    raise exception 'SANBANK_PERSONAL_LOAN_INVALID_TERMS';
  end if;
  v_installment := coalesce(nullif(new.payload->>'installment_amount','')::numeric, nullif(new.payload->>'estimated_payment','')::numeric);
  if v_installment is null or v_installment <= 0 then
    v_installment := round(v_amount * v_rate / (1 - power(1 + v_rate, -v_months)), 2);
  end if;
  v_due := coalesce(nullif(new.payload->>'first_due_date','')::date, nullif(new.payload->>'proposed_first_due_date','')::date);
  if v_due is null then
    v_due := (date_trunc('month', current_date) + make_interval(months => case when v_day <= extract(day from current_date) then 1 else 0 end) + (v_day - 1) * interval '1 day')::date;
  end if;
  if extract(day from v_due) <> v_day then raise exception 'SANBANK_PERSONAL_LOAN_DUE_DAY_MISMATCH'; end if;

  insert into public.sanbank_personal_loan_contracts(loan_id,account,principal,outstanding_balance,installment_amount,installment_count,due_day,next_due_date,monthly_rate)
  values(v_loan_id,v_account,v_amount,v_amount,v_installment,v_months,v_day,v_due,v_rate)
  on conflict (loan_id) do nothing;
  if not found then return new; end if;

  -- Liberação única, protegida pela chave idempotente do evento e executada na mesma transação.
  v_event_id := 'LOAN-DISBURSAL-' || v_loan_id;
  insert into public.sanbank_personal_loan_events(event_id,loan_id,account,event_type,amount)
  values(v_event_id,v_loan_id,v_account,'liberacao',v_amount)
  on conflict do nothing;
  if not found then return new; end if;
  update public.sanbank_accounts set balance = balance + v_amount, updated_at = now() where account = v_account;
  if not found then raise exception 'SANBANK_PERSONAL_LOAN_ACCOUNT_NOT_FOUND'; end if;
  perform public.sanbank_personal_loan_add_statement(v_loan_id,v_account,v_amount,'Entrada de crédito pessoal');
  return new;
end;
$$;

create or replace function public.sanbank_personal_loan_add_statement(p_event_id text,p_account text,p_amount numeric,p_title text)
returns void language plpgsql security definer set search_path=public,extensions
as $$
declare v_next integer; v_payload jsonb;
begin
  perform pg_advisory_xact_lock(hashtext('sanbank_legacy_records:extrato'));
  select coalesce(max(source_row),0)+1 into v_next from public.sanbank_legacy_records where source_tab='extrato';
  v_payload := jsonb_build_object('id',p_event_id,'account',p_account,'amount',p_amount,'title',p_title,'description',p_title,'date',to_char(now(),'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),'type',case when p_amount < 0 then 'saida' else 'entrada' end,'transaction_type',case when p_amount < 0 then 'debit' else 'credit' end,'status','concluido');
  insert into public.sanbank_legacy_records(source_tab,source_row,legacy_id,account,payload)
  values('extrato',v_next,p_event_id,p_account,v_payload)
  on conflict (source_tab,source_row) do nothing;
end;
$$;

-- A função de trigger e a função de gravação são internas; o disparo ocorre pela atualização administrativa da aba emprestimos.
drop trigger if exists sanbank_personal_loan_approval_trigger on public.sanbank_legacy_records;
create trigger sanbank_personal_loan_approval_trigger
after insert or update of payload on public.sanbank_legacy_records
for each row execute function public.sanbank_personal_loan_on_approval();

create or replace function public.sanbank_collect_personal_loan_installments()
returns integer language plpgsql security definer set search_path=public,extensions
as $$
declare c record; v_event_id text; v_count integer := 0; v_paid numeric(18,2); v_interest numeric(18,2); v_principal_paid numeric(18,2);
begin
  for c in select * from public.sanbank_personal_loan_contracts where contract_status='ativo' and next_due_date <= current_date order by next_due_date for update skip locked loop
    v_event_id := 'LOAN-INSTALLMENT-' || c.loan_id || '-' || (c.installments_paid + 1)::text;
    if exists(select 1 from public.sanbank_personal_loan_events where event_id=v_event_id) then
      update public.sanbank_personal_loan_contracts set installments_paid=installments_paid+1, next_due_date=(next_due_date + interval '1 month')::date, updated_at=now() where loan_id=c.loan_id;
      continue;
    end if;
    v_interest := round(c.outstanding_balance * c.monthly_rate, 2);
    v_paid := case when c.installments_paid + 1 >= c.installment_count then c.outstanding_balance + v_interest else least(c.installment_amount, c.outstanding_balance + v_interest) end;
    v_principal_paid := greatest(0, v_paid - v_interest);
    update public.sanbank_accounts set balance=balance-v_paid, updated_at=now() where account=c.account and balance >= v_paid;
    if not found then
      -- Mantém o vencimento vencido para tentar novamente no próximo ciclo, sem perder cobrança.
      update public.sanbank_personal_loan_contracts set last_collection_status='saldo_insuficiente', updated_at=now() where loan_id=c.loan_id;
      continue;
    end if;
    insert into public.sanbank_personal_loan_events(event_id,loan_id,account,event_type,amount)
    values(v_event_id,c.loan_id,c.account,'parcela',v_paid) on conflict do nothing;
    if not found then raise exception 'SANBANK_PERSONAL_LOAN_EVENT_CONFLICT'; end if;
    perform public.sanbank_personal_loan_add_statement(v_event_id,c.account,-v_paid,'Parcela de crédito pessoal');
    update public.sanbank_personal_loan_contracts
      set installments_paid=installments_paid+1,
          outstanding_balance=greatest(0,outstanding_balance-v_principal_paid),
          next_due_date=(next_due_date + interval '1 month')::date,
          contract_status=case when installments_paid+1 >= installment_count or greatest(0,outstanding_balance-v_principal_paid) < 0.01 then 'quitado' else 'ativo' end,
          last_collection_status='debitado', updated_at=now()
      where loan_id=c.loan_id;
    v_count := v_count+1;
  end loop;
  return v_count;
end;
$$;

revoke all on function public.sanbank_collect_personal_loan_installments() from public;
grant execute on function public.sanbank_collect_personal_loan_installments() to service_role;
revoke all on function public.sanbank_personal_loan_on_approval() from public;
revoke all on function public.sanbank_personal_loan_add_statement(text,text,numeric,text) from public;

-- Tenta instalar o processamento diário em segundo plano. Sem pg_cron, a função pode ser agendada via Supabase Cron.
do $$
begin
  begin
    create extension if not exists pg_cron;
    if not exists(select 1 from cron.job where jobname='sanbank-personal-loan-installments') then
      perform cron.schedule('sanbank-personal-loan-installments','5 3 * * *','select public.sanbank_collect_personal_loan_installments();');
    end if;
  exception when others then
    raise notice 'pg_cron indisponível; agende public.sanbank_collect_personal_loan_installments() diariamente no Supabase.';
  end;
end;
$$;
