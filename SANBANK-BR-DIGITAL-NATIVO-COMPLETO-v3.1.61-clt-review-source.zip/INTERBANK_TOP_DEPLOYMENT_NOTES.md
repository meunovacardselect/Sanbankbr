# Transferência TOP — instalação e revisão (não implantada)

Este pacote contém alterações locais para dois clientes Android, duas Edge Functions e SQL proposto. **Nada foi implantado em Supabase; nenhuma transferência ou alteração de saldo foi executada.** Não rode SQL, não publique Edge Functions e não configure produção sem autorização explícita e revisão operacional.

## O que a função representa

TOP apenas coordena registros em ledgers internos/demonstrativos destes aplicativos. Não é Pix ou DICT, não acessa uma rede bancária, não representa dinheiro real sob custódia e não realiza liquidação externa. O nome/titular vem do cadastro local de cada instituição.

## Arquivos locais

- MEU NOVA: `meu-nova-bank-android/supabase/meunova_interbank_top_v1.sql` e `meu-nova-bank-android/supabase/functions/interbank-top/index.ts`.
- SANBANK: `supabase_sanbank_interbank_top_v1.sql` e `sanbank-native-official/supabase/functions/interbank-top/index.ts`.
- Clientes: `meu-nova-bank-android/app/.../TransferenciaTopActivity.java` e `sanbank-native-official/app/.../TransferenciaTopActivity.java`.

## Preparação futura — requer autorização expressa

1. Revisar ambos os SQL e testar as funções em projetos isolados, com contas e saldos estritamente de teste. A migração MNB alarga a validação do número da conta para 6–7 dígitos em `account_login_map` e `customer_profiles`, e atualiza o RPC de login; ela **não** muda o gerador de contas, que continua gerando números de seis dígitos. Nenhuma conta de sete dígitos foi provisionada.
2. Implantar as migrações no projeto MEU NOVA (`hzgslpskmyzczqquendt`) e no SANBANK (`tvkcjntieqierukjnnjx`) somente após revisão e aceite do responsável. A ordem entre projetos precisa permitir que ambas as tabelas/RPCs existam antes de teste integrado.
3. Publicar cada função `interbank-top` no projeto correto. Em MEU NOVA, configurar somente no servidor `SANBANK_INTERBANK_TOP_FUNCTION_URL` apontando para a URL da função TOP SANBANK e `INTERBANK_TOP_HMAC_SECRET`. Em SANBANK, configurar somente no servidor `MEUNOVA_INTERBANK_TOP_FUNCTION_URL` apontando para a função TOP MEU NOVA e o mesmo `INTERBANK_TOP_HMAC_SECRET` forte e aleatório (mínimo recomendado 32 bytes). O Supabase injeta `SUPABASE_URL`, `SUPABASE_ANON_KEY`/`SUPABASE_SERVICE_ROLE_KEY` conforme ambiente; não copie service-role keys ou HMAC para o app, repositório público, logs ou ticket.
4. Confirmar autenticação: MEU NOVA usa Bearer JWT validado pelo Supabase Auth; SANBANK valida `x-sanbank-session` consultando `sanbank_sessions` no servidor. As chamadas institucionais são assinadas HMAC SHA-256 com timestamp. Ações de débito/crédito usam IDs UUID idempotentes e estado transacional persistido.
5. Antes de eventual teste, exigir contas dedicadas, financiadas apenas com saldos de teste, uma matriz de falhas (timeout antes/depois do débito, crédito repetido, insuficiência, conta inativa e concorrência) e conciliação manual de cada etapa. Não usar contas de clientes nem dados/saldos reais.

## Retomada e segurança do fluxo

A interface não pede nem mostra ID de transferência. Cada app consulta sua API autenticada para listar pendências; o identificador idempotente fica interno e é usado ao retomar a operação. A API de origem consulta a API da outra instituição no servidor via HMAC, sem expor segredo interbancário no APK. Se o débito de origem for confirmado e a resposta do destino estiver ambígua, o fluxo permanece pendente; a repetição faz prepare/commit idempotentes e **não** estorna automaticamente o débito. Débitos não confirmados não devem ser inferidos como realizados. A tela identifica explicitamente que o movimento é interno e demonstrativo.

## Limites conhecidos antes de ativar

- O suporte de sete dígitos foi alargado no backend MEU NOVA e no login do cliente para contas provisionadas. A criação de conta continua com seis dígitos por decisão de não alterar geração nem registros existentes.
- A edição/cadastro de contas no app administrativo MEU NOVA ainda deve ser revisada para eventual provisionamento de sete dígitos; não anuncie disponibilidade de contas novas de sete dígitos.
- Os dois APKs podem ser construídos localmente, mas só estarão operacionais após revisão e implantação autorizada das duas migrações e das duas funções.
