// Transferência TOP: coordenação de ledgers internos SANBANK ↔ MEU NOVA BANK.
// Nunca usa Pix/DICT nem liquidação externa. Todos os segredos permanecem em Edge Function secrets.
const headers = { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" };
const reply = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers });
const fail = (status: number, error: string) => reply({ error }, status);
const uuidV4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const accountPattern = /^\d{6,7}$/;
function hex(bytes: Uint8Array) { return [...bytes].map((b) => b.toString(16).padStart(2, "0")).join(""); }
function safeEqual(a: string, b: string) { if (a.length !== b.length) return false; let d = 0; for (let i=0;i<a.length;i++) d |= a.charCodeAt(i)^b.charCodeAt(i); return d===0; }
async function hmac(secret: string, value: string) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name:"HMAC", hash:"SHA-256" }, false, ["sign"]);
  return hex(new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(value))));
}
async function verify(req: Request, raw: string, secret: string) {
  const ts=req.headers.get("x-interbank-timestamp")||"", sig=(req.headers.get("x-interbank-signature")||"").toLowerCase();
  if (!/^\d{10}$/.test(ts)||!/^[0-9a-f]{64}$/.test(sig)||Math.abs(Math.floor(Date.now()/1000)-Number(ts))>300) return false;
  return safeEqual(await hmac(secret,`${ts}.${raw}`),sig);
}
async function rpc(url:string,service:string,name:string,body:unknown) {
  const r=await fetch(`${url}/rest/v1/rpc/${name}`,{method:"POST",headers:{apikey:service,Authorization:`Bearer ${service}`,"Content-Type":"application/json","Cache-Control":"no-store"},body:JSON.stringify(body)});
  const t=await r.text(); if(!r.ok) throw new Error(`RPC_${name}_${r.status}:${t.slice(0,350)}`); return t?JSON.parse(t):{};
}
async function rest(url:string,service:string,path:string) {
  const r=await fetch(`${url}/rest/v1/${path}`,{headers:{apikey:service,Authorization:`Bearer ${service}`,"Cache-Control":"no-store"}});
  const t=await r.text(); if(!r.ok) throw new Error(`REST_${r.status}`); return t?JSON.parse(t):[];
}
async function currentSession(url:string,service:string,token:string) {
  if(!/^[0-9a-f]{64}$/i.test(token)) return null;
  const rows=await rest(url,service,`sanbank_sessions?select=account,role,expires_at&token=eq.${encodeURIComponent(token)}&limit=1`);
  const s=Array.isArray(rows)?rows[0]:null;
  if(!s||!s.account||Date.parse(s.expires_at)<=Date.now()) return null;
  return {account:String(s.account),role:String(s.role||"user").toLowerCase()};
}
async function callMeunova(endpoint:string,secret:string,payload:unknown) {
  const ts=String(Math.floor(Date.now()/1000)),raw=JSON.stringify(payload),sig=await hmac(secret,`${ts}.${raw}`);
  const r=await fetch(endpoint,{method:"POST",headers:{"Content-Type":"application/json","Cache-Control":"no-store","x-interbank-timestamp":ts,"x-interbank-signature":sig},body:raw,signal:AbortSignal.timeout(15000)});
  const t=await r.text(); let body:any={}; try{body=t?JSON.parse(t):{};}catch{}
  if(!r.ok) throw new Error(`MEUNOVA_${r.status}:${String(body?.error||"request failed")}`); return body;
}
async function localMatch(url:string,service:string,account:string) {
  const rows=await rest(url,service,`sanbank_accounts?select=account,name,account_status,access_enabled,client_access_enabled&account=eq.${encodeURIComponent(account)}&limit=1`);
  const row=Array.isArray(rows)?rows[0]:null;
  if(!row||["closed","encerrada","locked","bloqueada","blocked"].includes(String(row.account_status||"").toLowerCase())||row.access_enabled===false||row.client_access_enabled===false) return null;
  return {institution:"SANBANK BR DIGITAL",account_number:String(row.account),display_name:String(row.name||"Titular SANBANK")};
}
async function continueTransfer(url:string,service:string,remoteUrl:string,secret:string,id:string,account:string) {
  const rows=await rest(url,service,`sanbank_top_transfers?select=*&transfer_id=eq.${encodeURIComponent(id)}&direction=eq.outgoing&sender_account=eq.${encodeURIComponent(account)}&limit=1`);
  const row=Array.isArray(rows)?rows[0]:null; if(!row) throw new Error("TOP_TRANSFER_NOT_FOUND");
  if(row.status==="completed") return {ok:true,status:"completed",transfer_id:id};
  if(row.status==="aborted"||row.status==="insufficient_funds") return {ok:false,status:row.status,transfer_id:id};
  const prepared=await callMeunova(remoteUrl,secret,{action:"prepare",transfer_id:id,source_institution:"SANBANK BR DIGITAL",sender_account:row.sender_account,sender_name:row.sender_name,recipient_account:row.recipient_account,amount:String(row.amount),currency:"BRL"});
  if(!prepared?.ok) throw new Error("TOP_PREPARE_FAILED");
  if(row.status==="prepared") {
    const debit=await rpc(url,service,"sanbank_top_debit_outgoing",{p_transfer_id:id});
    if(debit?.status==="insufficient_funds") {
      try{await callMeunova(remoteUrl,secret,{action:"abort",transfer_id:id,source_institution:"SANBANK BR DIGITAL"});}catch{}
      await rpc(url,service,"sanbank_top_finish_outgoing",{p_transfer_id:id,p_status:"aborted"});
      return {ok:false,status:"insufficient_funds",transfer_id:id};
    }
  }
  try {
    const committed=await callMeunova(remoteUrl,secret,{action:"commit",transfer_id:id,source_institution:"SANBANK BR DIGITAL"});
    if(committed?.status==="completed"||committed?.credit_confirmed===true) {
      await rpc(url,service,"sanbank_top_finish_outgoing",{p_transfer_id:id,p_status:"completed"});
      return {ok:true,status:"completed",transfer_id:id,recipient_account:row.recipient_account,amount:row.amount};
    }
  } catch { /* Debit confirmado: deixar pendente e permitir repetição idempotente. Nunca reverter. */ }
  return {ok:false,status:"source_debited_pending_credit",transfer_id:id,retryable:true};
}
Deno.serve(async(req)=>{
  if(req.method==="OPTIONS") return new Response(null,{status:204,headers:{...headers,"Access-Control-Allow-Origin":"*","Access-Control-Allow-Methods":"POST, OPTIONS","Access-Control-Allow-Headers":"authorization, apikey, content-type, x-sanbank-session"}});
  if(req.method!=="POST") return fail(405,"METHOD_NOT_ALLOWED");
  const url=Deno.env.get("SUPABASE_URL"),service=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const remoteUrl=Deno.env.get("MEUNOVA_INTERBANK_TOP_FUNCTION_URL"),secret=Deno.env.get("INTERBANK_TOP_HMAC_SECRET");
  if(!url||!service||!remoteUrl||!secret) return fail(503,"TOP_SERVICE_NOT_CONFIGURED");
  const raw=await req.text(); if(raw.length>8192) return fail(413,"REQUEST_TOO_LARGE");
  let input:any; try{input=JSON.parse(raw);}catch{return fail(400,"INVALID_JSON");}
  const action=typeof input.action==="string"?input.action:"";
  try {
    if(["lookup_remote","prepare","commit","abort"].includes(action)) {
      if(!(await verify(req,raw,secret))) return fail(401,"SIGNATURE_INVALID");
      if(action==="lookup_remote") {
        const account=typeof input.account_number==="string"?input.account_number:""; if(!accountPattern.test(account)) return fail(400,"ACCOUNT_INVALID");
        return reply({match:await localMatch(url,service,account)});
      }
      const id=typeof input.transfer_id==="string"?input.transfer_id:""; if(!uuidV4.test(id)) return fail(400,"TRANSFER_ID_INVALID");
      if(action==="prepare") {
        if(input.source_institution!=="MEU NOVA BANK BR DIGITAL"||input.currency!=="BRL") return fail(400,"INSTITUTION_INVALID");
        return reply(await rpc(url,service,"sanbank_top_prepare_incoming",{p_transfer_id:id,p_source_institution:input.source_institution,p_sender_account:input.sender_account,p_sender_name:input.sender_name,p_recipient_account:input.recipient_account,p_amount:String(input.amount)}));
      }
      if(action==="commit") return reply(await rpc(url,service,"sanbank_top_credit_incoming",{p_transfer_id:id}));
      return reply(await rpc(url,service,"sanbank_top_abort_incoming",{p_transfer_id:id}));
    }
    const session=await currentSession(url,service,req.headers.get("x-sanbank-session")||""); if(!session) return fail(401,"SESSION_INVALID");
    if(action==="lookup") {
      const account=typeof input.account_number==="string"?input.account_number.trim():""; if(!accountPattern.test(account)) return fail(400,"ACCOUNT_INVALID");
      if(await rpc(url,service,"sanbank_top_lookup_allowed",{p_actor_account:session.account})!==true) return fail(429,"LOOKUP_RATE_LIMIT");
      const [local,remote]=await Promise.all([localMatch(url,service,account),callMeunova(remoteUrl,secret,{action:"lookup_remote",account_number:account})]);
      return reply({matches:[local,remote?.match].filter(Boolean)});
    }
    if(action==="pending") {
      const rows=await rest(url,service,`sanbank_top_transfers?select=transfer_id,recipient_account,recipient_name,amount,status,created_at&direction=eq.outgoing&sender_account=eq.${encodeURIComponent(session.account)}&status=in.%28prepared%2Csource_debited%29&order=created_at.desc&limit=20`);
      return reply({transfers:(Array.isArray(rows)?rows:[]).map((row:any)=>({transfer_id:row.transfer_id,recipient_account:row.recipient_account,recipient_name:row.recipient_name,amount:row.amount,status:row.status,created_at:row.created_at}))});
    }
    if(action==="submit"||action==="status") {
      const id=typeof input.transfer_id==="string"?input.transfer_id:""; if(!uuidV4.test(id)) return fail(400,"TRANSFER_ID_INVALID");
      if(action==="submit") {
        const account=typeof input.recipient_account==="string"?input.recipient_account.trim():"";
        const institution=typeof input.destination_institution==="string"?input.destination_institution:"";
        const amount=typeof input.amount==="string"||typeof input.amount==="number"?String(input.amount):"";
        if(!accountPattern.test(account)||institution!=="MEU NOVA BANK BR DIGITAL"||!/^[0-9]{1,14}(?:\.[0-9]{1,2})?$/.test(amount)) return fail(400,"TOP_TRANSFER_DATA_INVALID");
        const senderRows=await rest(url,service,`sanbank_accounts?select=account,name,account_status,access_enabled,client_access_enabled&account=eq.${encodeURIComponent(session.account)}&limit=1`);
        const sender=Array.isArray(senderRows)?senderRows[0]:null;
        if(!sender||sender.account!==session.account) return fail(403,"SENDER_NOT_FOUND");
        if(["closed","encerrada","locked","bloqueada","blocked"].includes(String(sender.account_status||"").toLowerCase())||sender.access_enabled===false||sender.client_access_enabled===false) return fail(403,"SENDER_INACTIVE");
        const match=(await callMeunova(remoteUrl,secret,{action:"lookup_remote",account_number:account}))?.match;
        if(!match||match.institution!==institution||String(match.account_number)!==account) return fail(404,"RECIPIENT_NOT_FOUND");
        await rpc(url,service,"sanbank_top_create_outgoing",{p_transfer_id:id,p_sender_account:session.account,p_recipient_account:account,p_recipient_name:String(match.display_name||"Titular MEU NOVA BANK"),p_amount:amount});
      }
      return reply(await continueTransfer(url,service,remoteUrl,secret,id,session.account),action==="submit"?200:202);
    }
    return fail(400,"ACTION_INVALID");
  } catch(error) {
    const value=String(error);
    if(value.includes("TOP_RECIPIENT_NOT_FOUND")||value.includes("MEUNOVA_404")) return fail(404,"RECIPIENT_NOT_FOUND");
    if(value.includes("TOP_SENDER_INACTIVE")) return fail(403,"SENDER_INACTIVE");
    if(value.includes("TOP_SENDER_NOT_FOUND")) return fail(404,"SENDER_NOT_FOUND");
    if(value.includes("TOP_IDEMPOTENCY_CONFLICT")) return fail(409,"IDEMPOTENCY_CONFLICT");
    return fail(503,"TOP_TRANSFER_FAILED");
  }
});
