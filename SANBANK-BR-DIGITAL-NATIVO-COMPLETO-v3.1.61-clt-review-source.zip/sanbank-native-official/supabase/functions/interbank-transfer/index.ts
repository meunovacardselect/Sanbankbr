// SANBANK <-> MEU NOVA BANK: relay server-side de transferências proprietárias.
// Secrets (Supabase Edge Functions): MEUNOVA_INTERBANK_FUNCTION_URL,
// MEUNOVA_INTERBANK_HMAC_SECRET e SANBANK_INTERBANK_HMAC_SECRET.
const headers = { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" };
const reply = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers });
const fail = (status: number, code: string) => reply({ error: code }, status);
function hex(bytes: Uint8Array): string { return [...bytes].map((b) => b.toString(16).padStart(2, "0")).join(""); }
function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let x = 0; for (let i = 0; i < a.length; i++) x |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return x === 0;
}
async function sign(secret: string, text: string): Promise<string> {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return hex(new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(text))));
}
async function verifyHmac(req: Request, raw: string, secret: string): Promise<boolean> {
  const timestamp = req.headers.get("x-interbank-timestamp") || "";
  const supplied = (req.headers.get("x-interbank-signature") || "").toLowerCase();
  if (!/^\d{10}$/.test(timestamp) || !/^[0-9a-f]{64}$/.test(supplied)) return false;
  if (Math.abs(Math.floor(Date.now() / 1000) - Number(timestamp)) > 300) return false;
  return safeEqual(await sign(secret, `${timestamp}.${raw}`), supplied);
}
async function rpc(url: string, service: string, name: string, body: unknown, sessionToken?: string): Promise<any> {
  const h: Record<string, string> = { apikey: service, Authorization: `Bearer ${service}`, "Content-Type": "application/json", "Cache-Control": "no-store" };
  if (sessionToken) h["x-sanbank-session"] = sessionToken;
  const response = await fetch(`${url}/rest/v1/rpc/${name}`, { method: "POST", headers: h, body: JSON.stringify(body) });
  const text = await response.text();
  if (!response.ok) throw new Error(`RPC_${response.status}:${text.slice(0, 500)}`);
  return text ? JSON.parse(text) : {};
}
async function rest(url: string, service: string, path: string): Promise<any> {
  const response = await fetch(`${url}/rest/v1/${path}`, { headers: { apikey: service, Authorization: `Bearer ${service}`, "Cache-Control": "no-store" } });
  const text = await response.text();
  if (!response.ok) throw new Error(`REST_${response.status}:${text.slice(0, 400)}`);
  return text ? JSON.parse(text) : [];
}
async function currentSession(url: string, service: string, token: string): Promise<{ account: string; role: string } | null> {
  if (!/^[0-9a-f]{64}$/i.test(token)) return null;
  const rows = await rest(url, service, `sanbank_sessions?select=account,role,expires_at&token=eq.${encodeURIComponent(token)}&limit=1`);
  const s = Array.isArray(rows) ? rows[0] : null;
  if (!s || !s.account || Date.parse(s.expires_at) <= Date.now()) return null;
  return { account: String(s.account), role: String(s.role || "user").toLowerCase() };
}
async function callMeunova(url: string, secret: string, payload: unknown): Promise<any> {
  const timestamp = String(Math.floor(Date.now() / 1000));
  const raw = JSON.stringify(payload);
  const sig = await sign(secret, `${timestamp}.${raw}`);
  const response = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json", "Cache-Control": "no-store", "x-interbank-timestamp": timestamp, "x-interbank-signature": sig }, body: raw });
  const text = await response.text();
  let body: any = {}; try { body = text ? JSON.parse(text) : {}; } catch { body = {}; }
  if (!response.ok) throw new Error(`MEUNOVA_${response.status}:${String(body?.error || "request failed")}`);
  return body;
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "METHOD_NOT_ALLOWED");
  const url = Deno.env.get("SUPABASE_URL"), service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const meunovaUrl = Deno.env.get("MEUNOVA_INTERBANK_FUNCTION_URL");
  const meunovaSecret = Deno.env.get("MEUNOVA_INTERBANK_HMAC_SECRET");
  const inboundSecret = Deno.env.get("SANBANK_INTERBANK_HMAC_SECRET");
  if (!url || !service || !meunovaUrl || !meunovaSecret || !inboundSecret) return fail(503, "INTERBANK_SERVICE_NOT_CONFIGURED");
  const length = Number(req.headers.get("content-length") || "0"); if (length > 8192) return fail(413, "REQUEST_TOO_LARGE");
  const raw = await req.text(); if (raw.length > 8192) return fail(413, "REQUEST_TOO_LARGE");
  let input: any; try { input = JSON.parse(raw); } catch { return fail(400, "INVALID_JSON"); }
  const action = typeof input.action === "string" ? input.action : "";

  try {
    if (action === "submit" || action === "list_mine" || action === "source_review" || action === "list_admin" || action === "retry_delivery") {
      const token = req.headers.get("x-sanbank-session") || "";
      const session = await currentSession(url, service, token);
      if (!session) return fail(401, "SESSION_INVALID");
      if (action === "submit") {
        const target = typeof input.recipient_account === "string" ? input.recipient_account.trim() : "";
        const amount = typeof input.amount === "string" || typeof input.amount === "number" ? String(input.amount) : "";
        const id = typeof input.transfer_id === "string" ? input.transfer_id : "";
        if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id)
            || !/^\d{6}$/.test(target) || !/^\d{1,14}(?:[.,]\d{1,2})?$/.test(amount)) return fail(400, "TRANSFER_DATA_INVALID");
        const accountRows = await rest(url, service, `sanbank_accounts?select=account,name,account_status,access_enabled,client_access_enabled&account=eq.${encodeURIComponent(session.account)}&limit=1`);
        const accountRow = Array.isArray(accountRows) ? accountRows[0] : null;
        if (!accountRow || accountRow.account !== session.account) return fail(403, "SENDER_NOT_FOUND");
        if (["closed", "encerrada", "locked", "bloqueada", "blocked"].includes(String(accountRow.account_status || "").toLowerCase())
            || accountRow.access_enabled === false || accountRow.client_access_enabled === false) return fail(403, "SENDER_INACTIVE");
        const senderName = String(accountRow.name || "Titular SANBANK").trim().slice(0, 120) || "Titular SANBANK";
        const result = await rpc(url, service, "sanbank_create_interbank_transfer", {
          p_transfer_id: id, p_sender_account: session.account, p_sender_name: senderName,
          p_recipient_account: target, p_amount: amount.replace(",", "."),
        });
        return reply(result, 201);
      }
      if (action === "list_mine") {
        const rows = await rest(url, service, `sanbank_interbank_transfers?select=transfer_id,sender_account,sender_name,recipient_institution,recipient_account,amount,currency,status,created_at,source_debited_at,destination_credited_at&sender_account=eq.${encodeURIComponent(session.account)}&order=created_at.desc&limit=100`);
        return reply({ transfers: rows });
      }
      if (session.role !== "admin" && session.account !== "admin") return fail(403, "ADMIN_REQUIRED");
      if (action === "list_admin") {
        const rows = await rest(url, service, "sanbank_interbank_transfers?select=transfer_id,sender_account,sender_name,recipient_account,amount,currency,status,created_at,source_debited_at&order=created_at.desc&limit=200");
        return reply({ transfers: rows });
      }
      if (action === "retry_delivery") {
        const id = typeof input.transfer_id === "string" ? input.transfer_id : "";
        if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id)) return fail(400, "TRANSFER_ID_INVALID");
        const rows = await rest(url, service, `sanbank_interbank_transfers?select=transfer_id,source_operation_id,sender_account,sender_name,recipient_account,amount,currency,status,source_debited_at&transfer_id=eq.${encodeURIComponent(id)}&limit=1`);
        const row = Array.isArray(rows) ? rows[0] : null;
        if (!row) return fail(404, "TRANSFER_NOT_FOUND");
        if (row.status !== "awaiting_receiver_admin" || row.source_debited_at) return fail(409, "DELIVERY_RETRY_STATE_UNSAFE");
        try {
          const receiver = await callMeunova(meunovaUrl, meunovaSecret, {
            source_institution: "SANBANK BR DIGITAL", transfer_id: row.transfer_id,
            source_operation_id: row.source_operation_id, sender_account: row.sender_account,
            sender_name: row.sender_name, recipient_account: row.recipient_account,
            amount: String(row.amount), currency: "BRL",
          });
          return reply({ ok: true, status: row.status, delivery_status: "delivered", receiver });
        } catch {
          return reply({ ok: false, status: row.status, delivery_status: "retry_required", transfer_id: id }, 202);
        }
      }
      const id = typeof input.transfer_id === "string" ? input.transfer_id : "";
      const decision = typeof input.decision === "string" ? input.decision.toLowerCase() : "";
      if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id) || !["approve", "reject"].includes(decision)) return fail(400, "REVIEW_DATA_INVALID");
      const beforeRows = await rest(url, service, `sanbank_interbank_transfers?select=status&transfer_id=eq.${encodeURIComponent(id)}&limit=1`);
      const before = Array.isArray(beforeRows) ? beforeRows[0] : null;
      const reviewed = await rpc(url, service, "sanbank_review_interbank_source", { p_transfer_id: id, p_admin_account: session.account, p_decision: decision });
      if (decision === "reject") {
        if (before?.status === "awaiting_receiver_admin" || before?.status === "rejected") {
          try { const notified = await callMeunova(meunovaUrl, meunovaSecret, { action: "source_rejected", transfer_id: id }); return reply({ ...reviewed, destination_notified: true, destination_result: notified }); }
          catch { return reply({ ...reviewed, destination_notified: false, retry_required: true }, 202); }
        }
        return reply(reviewed);
      }
      const rows = await rest(url, service, `sanbank_interbank_transfers?select=transfer_id,source_operation_id,sender_account,sender_name,recipient_account,amount,currency,status&transfer_id=eq.${encodeURIComponent(id)}&limit=1`);
      const row = Array.isArray(rows) ? rows[0] : null;
      if (!row) return fail(404, "TRANSFER_NOT_FOUND");
      if (row.status === "awaiting_receiver_admin") {
        try {
          const received = await callMeunova(meunovaUrl, meunovaSecret, {
            source_institution: "SANBANK BR DIGITAL", transfer_id: row.transfer_id,
            source_operation_id: row.source_operation_id, sender_account: row.sender_account,
            sender_name: row.sender_name, recipient_account: row.recipient_account,
            amount: String(row.amount), currency: "BRL",
          });
          return reply({ ...reviewed, receiver: received });
        } catch {
          return reply({ ...reviewed, delivery_status: "retry_required" }, 202);
        }
      }
      return reply(reviewed);
    }

    if (action === "commit" || action === "receiver_rejected" || action === "credit_confirmed") {
      if (!(await verifyHmac(req, raw, inboundSecret))) return fail(401, "SIGNATURE_INVALID");
      const id = typeof input.transfer_id === "string" ? input.transfer_id : "";
      if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id)) return fail(400, "TRANSFER_ID_INVALID");
      if (action === "commit") {
        const result = await rpc(url, service, "sanbank_commit_interbank_transfer", { p_transfer_id: id });
        const status = String(result?.status || "");
        if (status === "insufficient_funds") return reply(result, 409);
        if (status === "security_blocked" || status === "sender_inactive") return reply(result, 409);
        return reply(result);
      }
      const finish = await rpc(url, service, "sanbank_finish_interbank_transfer", {
        p_transfer_id: id, p_result: action === "credit_confirmed" ? "completed" : "rejected",
      });
      return reply(finish);
    }
    return fail(400, "ACTION_INVALID");
  } catch (error) {
    const text = String(error);
    if (text.includes("INTERBANK_SENDER_NOT_FOUND")) return fail(404, "SENDER_NOT_FOUND");
    if (text.includes("INTERBANK_SENDER_INACTIVE")) return fail(403, "SENDER_INACTIVE");
    if (text.includes("INTERBANK_ADMIN_REQUIRED")) return fail(403, "ADMIN_REQUIRED");
    if (text.includes("INTERBANK_IDEMPOTENCY_CONFLICT")) return fail(409, "IDEMPOTENCY_CONFLICT");
    if (text.includes("MEUNOVA_404")) return fail(404, "RECIPIENT_NOT_FOUND");
    if (text.includes("MEUNOVA_409")) return fail(409, "RECEIVER_REJECTED_OR_CONFLICT");
    return fail(503, "INTERBANK_OPERATION_FAILED");
  }
});
