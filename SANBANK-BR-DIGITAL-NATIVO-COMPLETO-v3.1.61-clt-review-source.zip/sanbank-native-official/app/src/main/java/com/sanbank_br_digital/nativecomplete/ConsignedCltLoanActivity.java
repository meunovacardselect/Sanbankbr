package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.Locale;

/** Oferta individual de Crédito do Trabalhador (CLT), publicada pelo Gerente SANBANK. */
public final class ConsignedCltLoanActivity extends FunctionActivityBase {
    private LinearLayout content;
    private TextView status;
    private JSONObject offer;
    private EditText amountInput, monthsInput;
    private TextView simulation;
    private Button confirmButton;
    private double selectedAmount;
    private int selectedMonths;
    private double selectedInstallment;

    @Override protected void onModuleReady() {
        beginFunctionPage("Consignado CLT", "Crédito do Trabalhador · proposta individual da sua conta");
        LinearLayout banner = surfaceCard();
        banner.addView(text("CRÉDITO DO TRABALHADOR", 10, TEAL, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(20), 0, 5));
        banner.addView(text("Confira a oferta enviada pelo Gerente SANBANK. Simule dentro dos limites definidos para você e revise tudo antes de confirmar.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        addCard(banner, 12);
        status = statusText("Consultando se há uma oferta disponível para sua conta...");
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        page.addView(content, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        addBackButton();
        loadOffer();
    }

    private void loadOffer() {
        if (currentUser == null) { showEmpty("Não foi possível identificar sua conta."); return; }
        listTab("emprestimos", field(currentUser, "account"), new ListCallback() {
            @Override public void success(JSONArray records) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    java.util.ArrayList<JSONObject> offers = new java.util.ArrayList<>();
                    java.util.HashSet<String> consumedOfferIds = new java.util.HashSet<>();
                    JSONObject latestRequest = null;
                    for (int i=0; i<records.length(); i++) {
                        JSONObject row=records.optJSONObject(i); if(row==null) continue;
                        String product=firstField(row,"product","tipo","origem").toLowerCase(Locale.ROOT);
                        if (!product.contains("consignado_clt") && !product.contains("credito_trabalhador")) continue;
                        String state=firstField(row,"status","state").toLowerCase(Locale.ROOT);
                        if (state.equals("oferta_disponivel") || state.equals("disponivel") || state.equals("publicada")) offers.add(row);
                        else {
                            String usedId=firstField(row,"offer_id","oferta_id");
                            if(!usedId.isEmpty()) consumedOfferIds.add(usedId);
                            if(isWaiting(state)) latestRequest=row;
                        }
                    }
                    JSONObject latestOffer=null;
                    for(int i=offers.size()-1;i>=0;i--){JSONObject candidate=offers.get(i);String offerId=firstField(candidate,"id","legacy_id");if(!consumedOfferIds.contains(offerId)){latestOffer=candidate;break;}}
                    if(latestRequest!=null) showWaiting(latestRequest);
                    else { offer=latestOffer; if (offer==null) showEmpty("No momento não há uma nova oferta de consignado CLT disponível para sua conta. Ofertas já confirmadas não podem ser reutilizadas. Uma nova proposta aparecerá aqui quando o Gerente SANBANK publicar outra oferta."); else renderOffer(); }
                });
            }
            @Override public void failure(String message) { runOnUiThread(() -> { if (!isFinishing() && !isDestroyed()) showEmpty("Não foi possível consultar sua oferta agora. Tente atualizar a tela mais tarde."); }); }
        });
    }

    private boolean isWaiting(String state) {
        String s=state==null?"":state.toLowerCase(Locale.ROOT);
        return s.equals("confirmado_em_analise") || s.equals("em_analise") || s.equals("pendente") || s.equals("pending") || s.equals("aguardando_aprovacao") || s.equals("aguardando aprovação");
    }

    private void showWaiting(JSONObject request) {
        offer=null; content.removeAllViews(); status.setText("SOLICITAÇÃO AGUARDANDO O GERENTE");
        LinearLayout card=surfaceCard();
        card.addView(text("Pedido em análise",18,TEXT,true),lp(ViewGroup.LayoutParams.MATCH_PARENT,dp(30),0,8));
        card.addView(text("Sua solicitação de "+money(parseRecordAmount(request))+" em "+firstField(request,"months","parcelas","installments")+" parcelas foi enviada ao Gerente SANBANK. Enquanto ela estiver pendente, nenhuma nova oferta será exibida.",12,MUTED,false),lp(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT,0,9));
        card.addView(text("Status: aguardando confirmação do Gerente",11,TEAL,true),lp(ViewGroup.LayoutParams.MATCH_PARENT,dp(24),0,10));
        Button refresh=secondaryButton("Atualizar situação"); card.addView(refresh,lp(ViewGroup.LayoutParams.MATCH_PARENT,dp(46),0,0));
        refresh.setOnClickListener(v->loadOffer()); addCard(card,10);
    }

    private double parseRecordAmount(JSONObject row){try{return Double.parseDouble(firstField(row,"amount","valor","valorSolicitado").replace(",","."));}catch(Exception e){return 0;}}

    private void showEmpty(String message) {
        content.removeAllViews(); status.setText("CONSULTA DE OFERTA");
        LinearLayout card=surfaceCard(); card.addView(text("Nenhuma proposta para exibir",17,TEXT,true),lp(ViewGroup.LayoutParams.MATCH_PARENT,dp(29),0,7));
        card.addView(text(message,12,MUTED,false),lp(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT,0,12));
        Button refresh=secondaryButton("Consultar novamente"); card.addView(refresh,lp(ViewGroup.LayoutParams.MATCH_PARENT,dp(46),0,0)); refresh.setOnClickListener(v->loadOffer()); addCard(card,10);
    }

    private void renderOffer() {
        content.removeAllViews();
        double min=val("min_amount", "valor_minimo"); double max=val("max_amount", "valor_maximo");
        int minN=(int)val("min_installments","parcelas_minimas"); int maxN=(int)val("max_installments","parcelas_maximas");
        double rate=val("monthly_rate","taxa_juros"); double iof=val("iof_rate","taxa_iof");
        if(rate>1) rate/=100.0; if(iof>1) iof/=100.0;
        LinearLayout details=surfaceCard();
        details.addView(text("Sua proposta",19,TEXT,true),lp(ViewGroup.LayoutParams.MATCH_PARENT,dp(31),0,10));
        detail(details,"Valor disponível",money(max)); detail(details,"Faixa permitida",money(min)+" a "+money(max));
        detail(details,"Parcelas",minN+" a "+maxN+" meses"); detail(details,"Juros",percent(rate)+" ao mês"); detail(details,"IOF informado",percent(iof));
        String expiry=offerField(offer,"expires_at","valid_until","validade"); if(!expiry.isEmpty()) detail(details,"Validade",expiry);
        details.addView(text("A proposta depende da confirmação das condições e da análise final. A simulação é estimativa; nenhuma quantia é liberada nesta etapa.",10,MUTED,false),lp(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT,0,0));
        addCard(details,12);
        LinearLayout form=surfaceCard(); form.addView(text("Simule sua contratação",17,TEXT,true),lp(ViewGroup.LayoutParams.MATCH_PARENT,dp(29),0,8));
        form.addView(text("Valor solicitado",12,MUTED,true),lp(ViewGroup.LayoutParams.MATCH_PARENT,dp(22),0,4));
        amountInput=cltInput("Entre "+money(min)+" e "+money(max),false); form.addView(amountInput,lp(ViewGroup.LayoutParams.MATCH_PARENT,dp(50),0,9));
        form.addView(text("Número de parcelas",12,MUTED,true),lp(ViewGroup.LayoutParams.MATCH_PARENT,dp(22),0,4));
        monthsInput=cltInput("De "+minN+" a "+maxN, true); form.addView(monthsInput,lp(ViewGroup.LayoutParams.MATCH_PARENT,dp(50),0,9));
        Button simulate=secondaryButton("Calcular simulação"); form.addView(simulate,lp(ViewGroup.LayoutParams.MATCH_PARENT,dp(48),0,10));
        simulation=text("Informe o valor e o prazo para ver a estimativa.",12,MUTED,false); simulation.setPadding(dp(12),dp(12),dp(12),dp(12)); simulation.setBackground(rounded(Color.argb(220,8,34,51),Color.argb(75,45,212,191),16)); form.addView(simulation,lp(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT,0,10));
        confirmButton=primaryButton("Confirmar proposta"); confirmButton.setEnabled(false); form.addView(confirmButton,lp(ViewGroup.LayoutParams.MATCH_PARENT,dp(50),0,7));
        Button cancel=secondaryButton("Cancelar"); form.addView(cancel,lp(ViewGroup.LayoutParams.MATCH_PARENT,dp(46),0,0));
        addCard(form,10);
        simulate.setOnClickListener(v->calculate()); confirmButton.setOnClickListener(v->confirm()); cancel.setOnClickListener(v->finish());
        status.setText("Oferta disponível · revise os limites antes de confirmar.");
    }

    private EditText cltInput(String hint,boolean integer){ EditText e=functionInput(hint); e.setSingleLine(true); e.setInputType(InputType.TYPE_CLASS_NUMBER|(integer?0:InputType.TYPE_NUMBER_FLAG_DECIMAL)); return e; }
    private void calculate() {
        double amount=parseAmount(amountInput.getText().toString()); int months=number(monthsInput.getText().toString());
        double min=val("min_amount","valor_minimo"), max=val("max_amount","valor_maximo");
        int minN=(int)val("min_installments","parcelas_minimas"), maxN=(int)val("max_installments","parcelas_maximas");
        if(amount<min||amount>max||months<minN||months>maxN){ simulation.setText("Valor ou prazo fora dos limites desta oferta. Confira a faixa indicada acima."); confirmButton.setEnabled(false); return; }
        double rate=val("monthly_rate","taxa_juros"); if(rate>1)rate/=100.0; double iof=val("iof_rate","taxa_iof"); if(iof>1)iof/=100.0;
        double financed=amount*(1+iof); double payment=rate<=0?financed/months:financed*rate/(1-Math.pow(1+rate,-months));
        selectedAmount=amount; selectedMonths=months; selectedInstallment=Math.round(payment*100.0)/100.0; confirmButton.setEnabled(true);
        simulation.setText("Valor solicitado: "+money(amount)+"\nIOF estimado: "+money(amount*iof)+"\nJuros: "+percent(rate)+" ao mês\nParcela estimada: "+money(selectedInstallment)+"\nTotal estimado: "+money(selectedInstallment*months)+"\n\nEstimativa informativa, sujeita à validação final.");
    }
    private void confirm() {
        if(!confirmButton.isEnabled()||offer==null)return;
        confirmButton.setEnabled(false); status.setText("Registrando sua confirmação para análise...");
        JSONObject row=new JSONObject(); String id="CLT-REQ-"+field(currentUser,"account")+"-"+System.currentTimeMillis();
        try { row.put("id",id); row.put("account",field(currentUser,"account")); row.put("product","consignado_clt"); row.put("offer_id",offerField(offer,"id","legacy_id")); row.put("amount",selectedAmount); row.put("months",selectedMonths); row.put("monthly_rate",val("monthly_rate","taxa_juros")); row.put("iof_rate",val("iof_rate","taxa_iof")); row.put("estimated_payment",selectedInstallment); row.put("status","confirmado_em_analise"); row.put("date",isoNow()); }
        catch(Exception ignored){}
        apiUpsert("emprestimos",row,new RpcCallback(){
            @Override public void success(Object result){runOnUiThread(()->{content.removeAllViews();status.setText("CONFIRMAÇÃO REGISTRADA");LinearLayout done=surfaceCard();done.addView(text("Proposta enviada para análise",19,TEXT,true),lp(ViewGroup.LayoutParams.MATCH_PARENT,dp(32),0,8));done.addView(text("Sua solicitação de "+money(selectedAmount)+" em "+selectedMonths+" parcelas foi registrada. A confirmação não libera crédito automaticamente; aguarde a decisão do Gerente SANBANK.",13,MUTED,false),lp(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT,0,4));addCard(done,10);addBackButton();});}
            @Override public void failure(String message){runOnUiThread(()->{confirmButton.setEnabled(true);status.setText("Não foi possível registrar a confirmação. "+message);});}
        });
    }
    private void detail(LinearLayout box,String label,String value){TextView t=text(label+"\n"+value,12,TEXT,false);t.setPadding(dp(12),dp(9),dp(12),dp(9));t.setBackground(rounded(Color.argb(175,7,23,40),Color.argb(42,125,211,252),15));box.addView(t,lp(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT,0,6));}
    private double val(String...keys){for(String key:keys){String raw=offer==null?"":offer.optString(key,"");if(!raw.isEmpty())try{return Double.parseDouble(raw.replace(",","."));}catch(Exception ignored){}}return 0;}
    private String offerField(JSONObject object,String...keys){for(String key:keys){String value=field(object,key);if(!value.isEmpty())return value;}return "";}
    private double parseAmount(String raw){String s=raw.trim().replace("R$","").replace(" ","");if(s.matches("\\d{1,3}(?:\\.\\d{3})+,\\d{1,2}"))s=s.replace(".","").replace(',','.');else if(s.matches("\\d+,\\d{1,2}"))s=s.replace(',','.');else if(!s.matches("\\d+(?:\\.\\d{1,2})?"))return -1;try{return Double.parseDouble(s);}catch(Exception e){return -1;}}
    private String money(double amount){NumberFormat f=NumberFormat.getCurrencyInstance(new Locale("pt","BR"));return f.format(amount);}
    private String percent(double value){return String.format(new Locale("pt","BR"),"%.2f%%",value*100.0);}
}
