package com.sanbank_br_digital.app;

import android.app.admin.DeviceAdminReceiver;

/** Receptor de administrador do aparelho; não executa bloqueio nem apagamento remoto. */
public final class SanbankDeviceAdminReceiver extends DeviceAdminReceiver {
}
