package com.sanbank_br_digital.app;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Transferência proprietária sem Pix para conta de seis dígitos do MEU NOVA BANK. */
public final class InterbankTransferActivity extends NativeModuleActivity {
    private static final String FUNCTION_URL = SUPABASE_URL + "/functions/v1/interbank-transfer";
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private EditText recipient, amount;
    private TextView state, historyStatus, historyCount;
    private LinearLayout history;
    private Button send, refresh;

    @Override protected void onModuleReady() {
        root.removeAllViews();
        root.setBackgroundColor(NIGHT);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setClipToPadding(false);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(18), dp(20), dp(30));
        scroll.addView(page);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = roundedSanbankLogo();
        header.addView(logo, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setPadding(dp(12), 0, 0, 0);
        brand.addView(text("SANBANK BR DIGITAL", 10, TEAL, true), lp(-1, dp(18), 0, 2));
        brand.addView(text("TRANSFERÊNCIAS", 12, MUTED, true), lp(-1, dp(19), 0, 0));
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        page.addView(header, lp(-1, dp(52), 0, 14));

        page.addView(text("Transferência MEU NOVA BANK", 23, TEXT, true), lp(-1, -2, 0, 5));
        page.addView(text("Envie uma solicitação entre instituições com clareza e segurança.", 13, MUTED, false), lp(-1, -2, 0, 14));

        LinearLayout form = surfaceCard();
        form.setPadding(dp(17), dp(16), dp(17), dp(17));
        form.addView(text("Dados da transferência", 17, TEXT, true), lp(-1, dp(26), 0, 3));
        form.addView(text("Confira a conta e o valor antes de continuar.", 12, MUTED, false), lp(-1, -2, 0, 12));

        form.addView(text("CONTA DE DESTINO", 10, TEAL, true), lp(-1, dp(17), 0, 3));
        recipient = input("Conta MEU NOVA · 6 dígitos", false);
        recipient.setInputType(InputType.TYPE_CLASS_NUMBER);
        recipient.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(6)});
        form.addView(recipient, lp(-1, dp(54), 0, 10));

        form.addView(text("VALOR", 10, TEAL, true), lp(-1, dp(17), 0, 3));
        amount = input("Ex.: 125,50", false);
        amount.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        form.addView(amount, lp(-1, dp(54), 0, 10));

        String prefillAccount = getIntent() == null ? "" : getIntent().getStringExtra("prefill_recipient_account");
        String prefillAmount = getIntent() == null ? "" : getIntent().getStringExtra("prefill_amount");
        boolean fromQr = prefillAccount != null && prefillAccount.matches("\\d{6}") && prefillAmount != null && prefillAmount.matches("\\d{1,14}(?:[.,]\\d{1,2})?");
        if (fromQr) { recipient.setText(prefillAccount); amount.setText(prefillAmount); }

        state = text(fromQr ? "QR demonstrativo lido. Confira os dados: ele não credita saldo por si só." : "Preencha os dados para revisar a solicitação.", 12, fromQr ? Color.rgb(147, 197, 253) : MUTED, false);
        state.setPadding(dp(2), dp(4), dp(2), dp(4));
        form.addView(state, lp(-1, -2, 0, 8));
        send = primaryButton("Revisar e solicitar aprovação");
        form.addView(send, lp(-1, dp(54), 0, 0));
        send.setOnClickListener(v -> confirmSend());
        page.addView(form, lp(-1, -2, 0, 16));

        LinearLayout historyHeader = new LinearLayout(this);
        historyHeader.setOrientation(LinearLayout.HORIZONTAL);
        historyHeader.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout heading = new LinearLayout(this);
        heading.setOrientation(LinearLayout.VERTICAL);
        heading.addView(text("Meus pedidos", 18, TEXT, true), lp(-1, dp(25), 0, 2));
        historyCount = text("Atualizado ao consultar", 11, MUTED, false);
        heading.addView(historyCount, lp(-1, dp(18), 0, 0));
        historyHeader.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
        refresh = secondaryButton("Atualizar pedidos");
        refresh.setTextSize(12);
        historyHeader.addView(refresh, new LinearLayout.LayoutParams(-2, dp(44)));
        page.addView(historyHeader, lp(-1, -2, 0, 8));
        refresh.setOnClickListener(v -> loadMine());

        historyStatus = text("Carregando seus pedidos…", 12, MUTED, false);
        page.addView(historyStatus, lp(-1, -2, 0, 5));
        history = new LinearLayout(this);
        history.setOrientation(LinearLayout.VERTICAL);
        page.addView(history, lp(-1, -2, 0, 8));

        root.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        loadMine();
    }

    private void confirmSend() {
        String account = recipient.getText().toString().trim(), raw = amount.getText().toString().trim();
        if (!account.matches("\\d{6}")) { setState("A conta de destino deve ter exatamente 6 dígitos.", RED); return; }
        double value;
        try {
            String normalized = raw.replace("R$", "").replace(" ", "");
            if (normalized.contains(",") && normalized.contains(".")) {
                if (!normalized.matches("\\d{1,3}(?:\\.\\d{3})*,\\d{1,2}")) throw new Exception();
                normalized = normalized.replace(".", "").replace(',', '.');
            } else if (normalized.contains(",")) {
                if (!normalized.matches("\\d{1,14},\\d{1,2}")) throw new Exception();
                normalized = normalized.replace(',', '.');
            } else if (!normalized.matches("\\d{1,14}(?:\\.\\d{1,2})?")) throw new Exception();
            value = Double.parseDouble(normalized);
        } catch (Exception e) { setState("Valor inválido ou ambíguo. Use, por exemplo, 125,50.", RED); return; }
        if (value <= 0) { setState("O valor precisa ser maior que zero.", RED); return; }
        String preview = String.format(Locale.forLanguageTag("pt-BR"), "R$ %,.2f", value);
        new AlertDialog.Builder(this).setTitle("Revise os dados")
                .setMessage("Destino · MEU NOVA BANK\nConta: " + account + "\nValor: " + preview + "\n\nA solicitação depende de aprovação administrativa. Nenhum débito será feito agora.")
                .setNegativeButton("Voltar", null)
                .setPositiveButton("Solicitar aprovação", (d, w) -> submit(account, String.format(Locale.US, "%.2f", value))).show();
    }

    private void submit(String account, String value) {
        send.setEnabled(false);
        setState("Enviando solicitação segura…", MUTED);
        io.execute(() -> {
            String message = "Não foi possível enviar a solicitação. Confira a conexão e tente novamente.";
            int color = RED;
            try {
                JSONObject body = new JSONObject();
                body.put("action", "submit");
                body.put("transfer_id", UUID.randomUUID().toString());
                body.put("recipient_account", account);
                body.put("amount", value);
                JSONObject result = post(body);
                message = "Pedido enviado. Acompanhe o andamento em Meus pedidos.";
                color = TEAL;
            } catch (Exception ignored) { }
            final String done = message;
            final int doneColor = color;
            runOnUiThread(() -> {
                send.setEnabled(true);
                setState(done, doneColor);
                if (doneColor == TEAL) { recipient.setText(""); amount.setText(""); }
                loadMine();
            });
        });
    }

    private void loadMine() {
        if (historyStatus != null) historyStatus.setText("Consultando seus pedidos…");
        if (refresh != null) refresh.setEnabled(false);
        io.execute(() -> {
            JSONArray rows = null;
            try { rows = post(new JSONObject().put("action", "list_mine")).optJSONArray("transfers"); }
            catch (Exception ignored) { }
            final JSONArray value = rows;
            runOnUiThread(() -> {
                if (refresh != null) refresh.setEnabled(true);
                renderMine(value);
            });
        });
    }

    private void renderMine(JSONArray rows) {
        history.removeAllViews();
        if (rows == null) {
            historyStatus.setText("Não foi possível carregar o histórico. Toque em Atualizar pedidos para tentar novamente.");
            return;
        }
        historyCount.setText(rows.length() == 1 ? "1 solicitação" : rows.length() + " solicitações");
        historyStatus.setText("");
        if (rows.length() == 0) {
            LinearLayout empty = surfaceCard();
            TextView icon = text("↗", 25, TEAL, true); icon.setGravity(Gravity.CENTER);
            empty.addView(icon, lp(-1, dp(36), 0, 4));
            TextView title = text("Nenhum pedido ainda", 15, TEXT, true); title.setGravity(Gravity.CENTER);
            empty.addView(title, lp(-1, dp(25), 0, 3));
            TextView hint = text("Quando você solicitar uma transferência, o andamento aparecerá aqui.", 12, MUTED, false); hint.setGravity(Gravity.CENTER);
            empty.addView(hint, lp(-1, -2, 0, 0));
            history.addView(empty, lp(-1, -2, 0, 8));
            return;
        }
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row == null) continue;
            String account = row.optString("recipient_account", "—");
            String rawAmount = row.optString("amount", "0");
            String id = row.optString("transfer_id", "");
            String statusCode = row.optString("status", "");
            LinearLayout card = surfaceCard();
            card.setPadding(dp(15), dp(14), dp(15), dp(14));

            LinearLayout top = new LinearLayout(this);
            top.setOrientation(LinearLayout.HORIZONTAL);
            top.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout recipientInfo = new LinearLayout(this);
            recipientInfo.setOrientation(LinearLayout.VERTICAL);
            recipientInfo.addView(text("DESTINO · MEU NOVA BANK", 9, MUTED, true), lp(-1, dp(16), 0, 2));
            recipientInfo.addView(text("Conta " + account, 15, TEXT, true), lp(-1, dp(23), 0, 0));
            top.addView(recipientInfo, new LinearLayout.LayoutParams(0, -2, 1));
            TextView price = text(formatAmount(rawAmount), 17, TEXT, true);
            price.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
            top.addView(price, new LinearLayout.LayoutParams(-2, -2));
            card.addView(top, lp(-1, -2, 0, 9));

            TextView badge = text(label(statusCode), 11, statusColor(statusCode), true);
            badge.setGravity(Gravity.CENTER_VERTICAL);
            badge.setPadding(dp(10), dp(7), dp(10), dp(7));
            int badgeColor = statusColor(statusCode);
            badge.setBackground(rounded(Color.argb(27, Color.red(badgeColor), Color.green(badgeColor), Color.blue(badgeColor)), Color.argb(88, Color.red(badgeColor), Color.green(badgeColor), Color.blue(badgeColor)), 14));
            card.addView(badge, lp(-2, -2, 0, 8));

            String created = row.optString("created_at", "");
            if (!created.isEmpty()) card.addView(text("Solicitado · " + formatDate(created), 10, MUTED, false), lp(-1, dp(17), 0, 5));
            TextView idLine = text("ID · " + (id.isEmpty() ? "indisponível" : id), 10, MUTED, false);
            idLine.setSingleLine(true);
            idLine.setEllipsize(TextUtils.TruncateAt.END);
            card.addView(idLine, lp(-1, dp(17), 0, 1));
            if (!id.isEmpty()) {
                TextView copyHint = text("Toque para copiar o ID completo", 9, MUTED, false);
                card.addView(copyHint, lp(-1, dp(14), 0, 0));
                idLine.setOnClickListener(v -> copyId(id));
                copyHint.setOnClickListener(v -> copyId(id));
            }
            history.addView(card, lp(-1, -2, 0, 9));
        }
    }

    private void setState(String message, int color) {
        if (state != null) { state.setText(message); state.setTextColor(color); }
    }

    private void copyId(String id) {
        try {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("ID da transferência", id));
            Toast.makeText(this, "ID copiado.", Toast.LENGTH_SHORT).show();
        } catch (Exception ignored) { Toast.makeText(this, "Não foi possível copiar o ID.", Toast.LENGTH_SHORT).show(); }
    }

    private int statusColor(String status) {
        switch (status) {
            case "pending_source_admin": return Color.rgb(251, 191, 36);
            case "awaiting_receiver_admin": return Color.rgb(96, 165, 250);
            case "source_debited_pending_credit": return Color.rgb(251, 146, 60);
            case "completed": return TEAL;
            case "rejected": case "insufficient_funds": return RED;
            default: return MUTED;
        }
    }

    private String label(String status) {
        switch (status) {
            case "pending_source_admin": return "Aguardando análise do SANBANK";
            case "awaiting_receiver_admin": return "Aprovada no SANBANK · aguardando MEU NOVA";
            case "source_debited_pending_credit": return "Débito confirmado · aguardando confirmação do crédito";
            case "completed": return "Concluída nos registros das instituições";
            case "rejected": return "Recusada · nenhum crédito confirmado";
            case "insufficient_funds": return "Saldo ou limite disponível insuficiente";
            default: return "Em processamento · confira novamente mais tarde";
        }
    }

    private String formatAmount(String raw) {
        try {
            double value = Double.parseDouble(raw.replace(',', '.'));
            DecimalFormatSymbols symbols = new DecimalFormatSymbols(new Locale("pt", "BR"));
            return new DecimalFormat("R$ #,##0.00", symbols).format(value);
        } catch (Exception ignored) { return "R$ 0,00"; }
    }

    private String formatDate(String raw) {
        if (raw == null || raw.isEmpty()) return "";
        return raw.replace('T', ' ').replace("Z", "");
    }

    private JSONObject post(JSONObject body) throws Exception {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(FUNCTION_URL).openConnection();
            c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setDoOutput(true);
            c.setRequestProperty("apikey", SUPABASE_PUBLISHABLE_KEY);
            c.setRequestProperty("Authorization", "Bearer " + SUPABASE_PUBLISHABLE_KEY);
            c.setRequestProperty("x-sanbank-session", sessionToken);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("Cache-Control", "no-store");
            byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream out = c.getOutputStream()) { out.write(data); }
            int code = c.getResponseCode();
            InputStream stream = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            String response = readBody(stream);
            if (code < 200 || code >= 300) throw new Exception("request failed");
            return new JSONObject(response);
        } finally { if (c != null) c.disconnect(); }
    }

    private String readBody(InputStream in) throws Exception {
        if (in == null) return "";
        try (InputStream src = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] b = new byte[2048]; int n;
            while ((n = src.read(b)) != -1) { if (out.size() + n > 65536) throw new Exception("response too large"); out.write(b, 0, n); }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    @Override protected void onDestroy() { io.shutdownNow(); super.onDestroy(); }
}
