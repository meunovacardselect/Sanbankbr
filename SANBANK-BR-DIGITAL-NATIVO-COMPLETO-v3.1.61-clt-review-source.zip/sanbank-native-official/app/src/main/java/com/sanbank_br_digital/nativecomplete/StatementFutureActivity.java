package com.sanbank_br_digital.app;

/** Activity da categoria Lançamentos futuros do extrato. */
public final class StatementFutureActivity extends StatementCategoryActivity {
    @Override protected String categoryTitle() { return "Consulta de lançamento futuro"; }
    @Override protected String categoryDescription() { return "Consulte valor, descrição, instituição, data prevista e situação dos créditos agendados para sua conta."; }
    @Override protected String categoryKey() { return "future"; }
    @Override protected String categoryIconName() { return "ic_update"; }
}
