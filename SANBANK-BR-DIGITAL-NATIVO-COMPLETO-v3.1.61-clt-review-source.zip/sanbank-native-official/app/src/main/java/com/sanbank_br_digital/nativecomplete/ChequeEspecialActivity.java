package com.sanbank_br_digital.app;

import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;

/** Consulta, solicitação e condições do Cheque Especial. */
public final class ChequeEspecialActivity extends FunctionActivityBase {
    private TextView requestStatus;
    private Button requestButton;
    private boolean checking;
    @Override protected void onModuleReady() { render(); }
    private void render() {
        beginFunctionPage("Cheque Especial", "Solicite um limite sujeito à análise administrativa.");
        boolean enabled = isOverdraftVisible();
        double total = overdraftTotalLimit(), used = enabled ? Math.min(total, overdraftUsedAmount()) : 0;
        LinearLayout summary = surfaceCard();
        summary.addView(text(enabled ? "Limite habilitado" : "Ainda sem limite aprovado", 16, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 6));
        addDetailRow(summary, "Limite contratado", formatMoney(total), TEXT);
        addDetailRow(summary, "Valor utilizado", formatMoney(used), Color.rgb(248,113,113));
        addDetailRow(summary, "Disponível", formatMoney(availableOverdraft()), Color.rgb(52,211,153));
        addCard(summary, 10);
        LinearLayout costs = surfaceCard();
        costs.addView(text("Custos e prazos", 15, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(27), 0, 6));
        addDetailRow(costs,"IOF sobre o valor utilizado","1,2%",Color.rgb(251,191,36));
        addDetailRow(costs,"Juros após carência","5,9%",Color.rgb(248,113,113));
        addDetailRow(costs,"Carência antes dos juros","4 dias",TEXT);
        addDetailRow(costs,"Parcelamento por atraso > 40 dias","até 12 vezes",TEXT);
        TextView legal = text("Os encargos são calculados sobre o valor utilizado. O parcelamento depende da análise e das condições aplicáveis.",10,MUTED,false);
        legal.setPadding(0,dp(6),0,0); costs.addView(legal,lp(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT,0,0)); addCard(costs,10);
        requestStatus = text("Limite solicitado permitido: de R$ 50,00 a R$ 90.000,00. A concessão depende de análise administrativa.",11,MUTED,false);
        requestStatus.setPadding(dp(10),dp(8),dp(10),dp(8)); page.addView(requestStatus,lp(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT,0,6));
        requestButton=primaryButton("Solicitar Cheque Especial"); requestButton.setOnClickListener(v -> askAmount()); page.addView(requestButton,lp(ViewGroup.LayoutParams.MATCH_PARENT,dp(52),0,10));
        addBackButton();
    }
    private void askAmount() {
        EditText input=functionInput("Valor desejado (R$ 50 a R$ 90.000)"); input.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        new AlertDialog.Builder(this).setTitle("Solicitar limite").setMessage("Informe o limite pretendido. O pedido será enviado para análise administrativa.").setView(input)
                .setNegativeButton("Cancelar",null).setPositiveButton("Revisar",(d,w)->submitAmount(input.getText().toString())).show();
    }
    private void submitAmount(String raw) {
        double amount=decimal(raw); if(amount<50 || amount>90000){requestStatus.setText("Informe um valor entre R$ 50,00 e R$ 90.000,00.");return;}
        if(checking)return; checking=true; requestButton.setEnabled(false); requestStatus.setText("Verificando se existe solicitação ou bloqueio vigente...");
        String account=field(currentUser,"account"); listTab("analise_cheque_especial",account,new ListCallback(){
            @Override public void success(JSONArray rows){ long now=System.currentTimeMillis();
                for(int i=0;i<rows.length();i++){JSONObject r=rows.optJSONObject(i); if(r==null)continue;
                    String status=firstField(r,"status","analysis_status").toLowerCase(Locale.ROOT);
                    long block=parseDate(firstField(r,"blocked_until","new_request_blocked_until"));
                    if(block>now){finishRequest("Nova solicitação bloqueada até " + firstField(r,"blocked_until","new_request_blocked_until")+".");return;}
                    if(status.matches(".*(pending|pendente|aguardando|under_analysis|em_an[aá]lise).*")){finishRequest("Você já possui uma solicitação em análise. Aguarde a decisão administrativa.");return;}
                }
                JSONObject record=new JSONObject(); String id="OVERDRAFT-"+account+"-"+now;
                try{record.put("id",id);record.put("account",account);record.put("requested_limit",String.format(Locale.US,"%.2f",amount));record.put("amount",String.format(Locale.US,"%.2f",amount));record.put("status","pending");record.put("analysis_status","pending");record.put("created_at",isoNow());record.put("requested_by",account);record.put("iof_rate",0.012);record.put("interest_rate",0.059);record.put("grace_days",4);record.put("installment_after_days",40);record.put("max_installments",12);}catch(Exception ignored){}
                apiUpsert("analise_cheque_especial",record,new RpcCallback(){@Override public void success(Object r){finishRequest("Pedido enviado para análise administrativa. Você verá a decisão nesta área.");}@Override public void failure(String e){finishRequest("Não foi possível enviar o pedido. Tente novamente mais tarde.");}});
            }
            @Override public void failure(String e){finishRequest("Não foi possível consultar as solicitações existentes.");}
        });
    }
    private void finishRequest(String message){checking=false;requestButton.setEnabled(true);requestStatus.setText(message);}
    private long parseDate(String raw){try{return android.text.format.DateFormat.getDateFormat(this).parse(raw).getTime();}catch(Exception ignored){try{return new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US).parse(raw.substring(0,19)).getTime();}catch(Exception e){return 0;}}}
    private void addDetailRow(LinearLayout p,String label,String value,int color){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView l=text(label,12,MUTED,false);row.addView(l,new LinearLayout.LayoutParams(0,dp(29),1));TextView r=text(value,13,color,true);r.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);row.addView(r,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,dp(29)));p.addView(row,lp(ViewGroup.LayoutParams.MATCH_PARENT,dp(31),0,1));}
}
