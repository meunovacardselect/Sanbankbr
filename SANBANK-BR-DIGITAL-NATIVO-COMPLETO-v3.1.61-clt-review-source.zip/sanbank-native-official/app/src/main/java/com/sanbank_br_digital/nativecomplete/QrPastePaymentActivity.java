package com.sanbank_br_digital.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Locale;

/** Colagem, validação e confirmação de cobrança QR gerada como payload textual. */
public final class QrPastePaymentActivity extends FunctionActivityBase {
    private EditText payloadInput;
    private TextView status;
    private TextView reviewStatus;
    private LinearLayout reviewCard;
    private Button confirmButton;
    private String targetAccount = "", targetName = "", description = "", institution = "";
    private BigDecimal amount = BigDecimal.ZERO;
    private boolean meunovaQr;

    @Override protected void onModuleReady() {
        beginFunctionPage("Colar código QR", "Cole o conteúdo do QR Code gerado, confira os dados e só então continue.");
        LinearLayout inputCard = surfaceCard();
        inputCard.addView(text("Conteúdo do QR Code", 14, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(25), 0, 6));
        payloadInput = functionInput("Cole aqui o código QR");
        payloadInput.setGravity(Gravity.TOP | Gravity.START);
        payloadInput.setSingleLine(false);
        payloadInput.setMinLines(4);
        payloadInput.setMaxLines(8);
        payloadInput.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(8192)});
        inputCard.addView(payloadInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(120), 0, 9));
        Button paste = secondaryButton("Colar da área de transferência");
        inputCard.addView(paste, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(46), 0, 8));
        paste.setOnClickListener(v -> pasteFromClipboard());
        Button validate = primaryButton("Conferir código QR");
        inputCard.addView(validate, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(49), 0, 0));
        validate.setOnClickListener(v -> validatePayload());
        addCard(inputCard, 10);

        status = statusText("Nenhum código conferido.");
        reviewCard = surfaceCard();
        reviewCard.setVisibility(View.GONE);
        reviewCard.addView(text("Revise os dados", 17, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(29), 0, 8));
        reviewCard.addView(text("Instituição", 10, MUTED, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(18), 0, 2));
        reviewCard.addView(text("", 14, Color.rgb(219, 234, 254), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(25), 0, 5));
        reviewCard.addView(text("Titular", 10, MUTED, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(18), 0, 2));
        reviewCard.addView(text("", 14, Color.rgb(219, 234, 254), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(25), 0, 5));
        reviewCard.addView(text("Conta", 10, MUTED, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(18), 0, 2));
        reviewCard.addView(text("", 14, Color.rgb(219, 234, 254), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(25), 0, 5));
        reviewCard.addView(text("Valor", 10, MUTED, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(18), 0, 2));
        reviewCard.addView(text("", 22, Color.rgb(110, 231, 183), true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(32), 0, 6));
        reviewCard.addView(text("", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 7));
        reviewStatus = text("", 12, Color.rgb(167, 243, 208), false);
        reviewCard.addView(reviewStatus, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 9));
        confirmButton = primaryButton("Confirmar pagamento");
        reviewCard.addView(confirmButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 0));
        confirmButton.setOnClickListener(v -> continuePayment());
        addCard(reviewCard, 10);
        addBackButton();
    }

    private void pasteFromClipboard() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard == null || !clipboard.hasPrimaryClip()) { status.setText("A área de transferência está vazia."); return; }
        ClipData clip = clipboard.getPrimaryClip();
        if (clip == null || clip.getItemCount() == 0) { status.setText("Não encontrei texto para colar."); return; }
        CharSequence text = clip.getItemAt(0).coerceToText(this);
        if (text == null || text.length() == 0) { status.setText("Não encontrei texto para colar."); return; }
        if (text.length() > 8192) { status.setText("O conteúdo excede o limite aceito."); return; }
        payloadInput.setText(text);
        status.setText("Código colado. Toque em Conferir código QR.");
    }

    private void validatePayload() {
        reviewCard.setVisibility(View.GONE);
        String raw = payloadInput.getText().toString().trim();
        if (raw.isEmpty() || raw.length() > 8192) { status.setText("Cole o conteúdo textual de um QR Code válido."); return; }
        JSONObject data = null;
        try { data = new JSONObject(raw); } catch (Exception ignored) { }
        if (data != null) {
            targetAccount = first(data, "account", "recipient_account", "conta");
            targetName = first(data, "recipient_name", "name", "nome");
            description = first(data, "desc", "description", "descricao");
            institution = first(data, "institution", "institution_name", "recipient_institution", "instituicao");
            String currency = first(data, "currency", "moeda");
            if (!currency.isEmpty() && !"BRL".equalsIgnoreCase(currency)) { status.setText("Moeda não compatível. Só aceito códigos em BRL."); return; }
            meunovaQr = "meunovabank_deposito_demo".equalsIgnoreCase(first(data, "type", "tipo"))
                    || institution.toLowerCase(Locale.ROOT).contains("meu nova bank");
            try { amount = new BigDecimal(first(data, "amount", "valor").replace(',', '.')).setScale(2, RoundingMode.UNNECESSARY); }
            catch (Exception error) { amount = BigDecimal.ZERO; }
        } else {
            targetAccount = ""; targetName = ""; description = ""; institution = ""; amount = BigDecimal.ZERO; meunovaQr = false;
            String[] parts = raw.split("[;|&]");
            String rawAmount = "";
            for (String part : parts) {
                String[] pair = part.split("=", 2);
                if (pair.length != 2) continue;
                String key = pair[0].trim().toLowerCase(Locale.ROOT), value = pair[1].trim();
                if ("account".equals(key) || "conta".equals(key) || "recipient_account".equals(key)) targetAccount = value;
                else if ("name".equals(key) || "nome".equals(key) || "recipient_name".equals(key)) targetName = value;
                else if ("amount".equals(key) || "valor".equals(key)) rawAmount = value;
                else if ("desc".equals(key) || "description".equals(key) || "descricao".equals(key)) description = value;
                else if ("institution".equals(key) || "instituicao".equals(key)) institution = value;
            }
            try { amount = new BigDecimal(rawAmount.replace(',', '.')).setScale(2, RoundingMode.UNNECESSARY); }
            catch (Exception error) { amount = BigDecimal.ZERO; }
            meunovaQr = institution.toLowerCase(Locale.ROOT).contains("meu nova bank");
        }
        if (!targetAccount.matches("\\d{6}") || amount.signum() <= 0) { status.setText("QR inválido: confira se contém conta com 6 dígitos e valor positivo."); return; }
        if (targetAccount.equals(field(currentUser, "account"))) { status.setText("Não é possível pagar um QR da sua própria conta."); return; }
        if (targetName.isEmpty()) targetName = "Titular do QR";
        if (description.isEmpty()) description = "Cobrança QR";
        if (institution.isEmpty()) institution = "SANBANK BR DIGITAL";
        setReview(2, institution);
        setReview(4, targetName);
        setReview(6, targetAccount);
        setReview(8, formatMoney(amount.doubleValue()));
        setReview(9, "Descrição: " + description);
        if (meunovaQr) {
            reviewStatus.setText("QR do MEU NOVA BANK identificado. A solicitação será encaminhada pelo fluxo interbancário e exigirá as aprovações dos dois bancos.");
            confirmButton.setText("Continuar transferência ao MEU NOVA");
        } else {
            reviewStatus.setText("O pagamento ficará pendente de aprovação administrativa. Nenhum débito ocorre agora.");
            confirmButton.setText("Solicitar pagamento QR");
        }
        reviewCard.setVisibility(View.VISIBLE);
        status.setText("Confira cuidadosamente o titular, a conta e o valor.");
    }

    private String first(JSONObject object, String... keys) {
        for (String key : keys) {
            Object value = object.opt(key);
            if (value != null && value != JSONObject.NULL) {
                String text = String.valueOf(value).trim();
                if (!text.isEmpty()) return text;
            }
        }
        return "";
    }

    private void setReview(int child, String value) {
        if (child >= 0 && child < reviewCard.getChildCount() && reviewCard.getChildAt(child) instanceof TextView) {
            ((TextView) reviewCard.getChildAt(child)).setText(value);
        }
    }

    private void continuePayment() {
        if (meunovaQr) {
            if (!moduleFeaturesEnabled(InterbankTransferActivity.class)) { Toast.makeText(this, "A transferência interbancária está desabilitada.", Toast.LENGTH_LONG).show(); return; }
            Intent intent = new Intent(this, InterbankTransferActivity.class);
            intent.putExtra("prefill_recipient_account", targetAccount);
            intent.putExtra("prefill_amount", amount.toPlainString());
            startActivity(intent);
            return;
        }
        confirmButton.setEnabled(false);
        reviewStatus.setText("Enviando solicitação para aprovação administrativa...");
        JSONObject payload = new JSONObject();
        try {
            payload.put("id", "PAYMENT_QR-" + field(currentUser, "account") + "-" + System.currentTimeMillis());
            payload.put("account", field(currentUser, "account"));
            payload.put("sender_account", field(currentUser, "account"));
            payload.put("target_account", targetAccount);
            payload.put("target_name", targetName);
            payload.put("amount", amount.toPlainString());
            payload.put("transaction_type", "PAYMENT_QR");
            payload.put("description", "Pagamento QR para " + targetName + " — " + description);
            payload.put("status", "pending");
            payload.put("created_at", isoNow());
        } catch (Exception ignored) { }
        apiUpsert("pendentes", payload, new RpcCallback() {
            @Override public void success(Object result) { runOnUiThread(() -> { confirmButton.setEnabled(true); reviewStatus.setText("Solicitação QR registrada e aguardando aprovação. Nenhum pagamento externo foi realizado."); }); }
            @Override public void failure(String message) { runOnUiThread(() -> { confirmButton.setEnabled(true); reviewStatus.setText(message); }); }
        });
    }
}
