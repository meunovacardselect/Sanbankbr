package com.sanbank_br_digital.app;

import android.content.Intent;
import android.os.Bundle;

/** Painel principal do SANBANK BR DIGITAL; sem dependência do PAY Services. */
public final class MainActivity extends NativeBaseActivity {
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (!restoreSavedSession()) {
            completeLoadingThen(this::launchLogin);
            return;
        }
        checkSecurityThenOpen();
    }

    private void launchLogin() {
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }
}
