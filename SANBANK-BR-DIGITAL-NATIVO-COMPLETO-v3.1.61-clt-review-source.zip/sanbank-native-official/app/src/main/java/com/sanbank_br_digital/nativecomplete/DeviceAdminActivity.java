package com.sanbank_br_digital.app;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Ativa ou remove, sempre com confirmação explícita do Android, o administrador local. */
public final class DeviceAdminActivity extends FunctionActivityBase {
    private static final int REQUEST_ENABLE_ADMIN = 7713;
    private DevicePolicyManager policyManager;
    private ComponentName adminComponent;
    private TextView status;
    private Button action;

    @Override protected void onModuleReady() {
        policyManager = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        adminComponent = new ComponentName(this, SanbankDeviceAdminReceiver.class);
        beginFunctionPage("Administrador do dispositivo", "Ativação opcional, controlada pelo Android.");
        LinearLayout card = surfaceCard();
        card.addView(text("O que esta permissão faz", 16, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));
        card.addView(text("Como administrador, o SANBANK solicitará somente a permissão de bloqueio da tela e observação de tentativas de login. Não pedirá permissão para apagar os dados do aparelho. A ativação depende da sua confirmação no Android e pode ser revogada nas configurações do sistema.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        addCard(card, 12);
        status = statusText("");
        action = primaryButton("");
        page.addView(action, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 8));
        action.setOnClickListener(v -> handleAction());
        Button back = secondaryButton("Voltar");
        page.addView(back, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 0));
        back.setOnClickListener(v -> finish());
        refreshState();
    }

    private void refreshState() {
        boolean active = policyManager != null && policyManager.isAdminActive(adminComponent);
        status.setText(active ? "Administrador ativado neste aparelho." : "Administrador não ativado. O aplicativo funciona normalmente sem esta permissão.");
        status.setTextColor(active ? Color.rgb(74, 222, 128) : MUTED);
        action.setText(active ? "Revogar administrador" : "Ativar administrador");
    }

    private void handleAction() {
        if (policyManager == null) {
            status.setText("Não foi possível abrir o serviço de administração deste Android.");
            return;
        }
        if (policyManager.isAdminActive(adminComponent)) {
            policyManager.removeActiveAdmin(adminComponent);
            status.setText("Pedido de revogação enviado ao Android.");
            refreshState();
        } else {
            Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent);
            intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "O SANBANK solicita permissão para bloquear a tela. A ativação é opcional e depende da sua confirmação.");
            startActivityForResult(intent, REQUEST_ENABLE_ADMIN);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ENABLE_ADMIN) refreshState();
    }

    @Override protected void onResume() {
        super.onResume();
        if (status != null) refreshState();
    }
}
