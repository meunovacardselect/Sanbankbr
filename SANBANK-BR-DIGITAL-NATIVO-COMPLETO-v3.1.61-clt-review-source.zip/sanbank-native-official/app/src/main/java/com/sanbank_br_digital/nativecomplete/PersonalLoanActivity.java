package com.sanbank_br_digital.app;

import android.text.InputType;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/** Empréstimo pessoal com simulação e envio para a aba emprestimos. */
public final class PersonalLoanActivity extends FunctionActivityBase {
    private EditText amountInput;
    private EditText monthsInput;
    private EditText dueDayInput;
    private TextView status;

    @Override
    protected void onModuleReady() {
        beginFunctionPage("Crédito pessoal", "Solicite de R$ 100 a R$ 120.000. O gerente analisa; nenhuma quantia é liberada antes da aprovação.");
        LinearLayout form = surfaceCard();
        form.addView(text("Valor do empréstimo", 14, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 6));
        amountInput = loanInput("Entre R$ 100,00 e R$ 120.000,00", false);
        form.addView(amountInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 9));
        form.addView(text("Parcelas", 14, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 6));
        monthsInput = loanInput("Entre 2 e 48 parcelas", true);
        form.addView(monthsInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 9));
        form.addView(text("Dia mensal preferido para vencimento", 14, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 6));
        dueDayInput = loanInput("De 1 a 28", true);
        form.addView(dueDayInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 9));
        form.addView(text("Simulação indicativa a 1,84% ao mês. Taxa, parcela e condições finais dependem da aprovação do gerente. O vencimento será mensal no dia escolhido.", 11, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        Button request = primaryButton("Simular e solicitar");
        form.addView(request, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 0));
        addCard(form, 10);
        status = statusText("A solicitação não altera o saldo antes da aprovação.");
        request.setOnClickListener(v -> submit(request));
        addBackButton();
    }

    private EditText loanInput(String hint, boolean integer) {
        EditText input = functionInput(hint);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | (integer ? 0 : InputType.TYPE_NUMBER_FLAG_DECIMAL));
        return input;
    }

    private void submit(Button button) {
        double amount = decimal(amountInput.getText().toString());
        int months = number(monthsInput.getText().toString());
        int dueDay = number(dueDayInput.getText().toString());
        if (amount < 100 || amount > 120000 || months < 2 || months > 48 || dueDay < 1 || dueDay > 28) { status.setText("Confira: valor de R$ 100 a R$ 120.000, prazo de 2 a 48 parcelas e vencimento entre os dias 1 e 28."); return; }
        double rate = 0.0184;
        double payment = amount * rate / (1 - Math.pow(1 + rate, -months));
        button.setEnabled(false);
        status.setText("Enviando solicitação para análise...");
        JSONObject payload = new JSONObject();
        try {
            payload.put("id", "SANBANK-PESSOAL-" + field(currentUser, "account") + "-" + System.currentTimeMillis());
            payload.put("account", field(currentUser, "account"));
            payload.put("amount", Math.round(amount * 100.0) / 100.0);
            payload.put("months", months);
            payload.put("estimated_payment", Math.round(payment * 100.0) / 100.0);
            payload.put("monthly_rate_estimated", rate);
            payload.put("requested_due_day", dueDay);
            payload.put("proposed_first_due_date", firstDueDate(dueDay));
            payload.put("product", "credito_pessoal");
            payload.put("date", isoNow());
            payload.put("status", "em_analise");
        } catch (Exception ignored) { }
        apiUpsert("emprestimos", payload, new RpcCallback() {
            @Override public void success(Object result) { runOnUiThread(() -> { button.setEnabled(true); status.setText("Solicitação registrada para análise. Parcela estimada: " + formatMoney(payment) + "; vencimento mensal preferido dia " + dueDay + "."); }); }
            @Override public void failure(String message) { runOnUiThread(() -> { button.setEnabled(true); status.setText(message); }); }
        });
    }
    private String firstDueDate(int day) {
        Calendar due = Calendar.getInstance();
        due.set(Calendar.DAY_OF_MONTH, day);
        due.set(Calendar.HOUR_OF_DAY, 12); due.set(Calendar.MINUTE, 0); due.set(Calendar.SECOND, 0); due.set(Calendar.MILLISECOND, 0);
        Calendar today = Calendar.getInstance();
        today.set(Calendar.HOUR_OF_DAY, 0); today.set(Calendar.MINUTE, 0); today.set(Calendar.SECOND, 0); today.set(Calendar.MILLISECOND, 0);
        if (!due.after(today)) due.add(Calendar.MONTH, 1);
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(due.getTime());
    }
}
